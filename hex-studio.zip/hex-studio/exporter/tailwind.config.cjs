/** @type {import('tailwindcss').Config} */
module.exports = {
  presets: [require('../tailwind.preset.cjs')],
  content: ['./app/**/*.{ts,tsx}', '../src/shared/**/*.{ts,tsx}'],
};

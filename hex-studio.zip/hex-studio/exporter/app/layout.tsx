import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import '../../src/shared/tokens.css';
import './globals.css';
import { loadSite } from './load-site';

export function generateMetadata(): Metadata {
  const { doc, name } = loadSite();
  return { title: doc.seo.title || name, description: doc.seo.description || undefined };
}

export default function RootLayout({ children }: { children: ReactNode }) {
  const { doc } = loadSite();
  return (
    <html lang={doc.lang}>
      <body>{children}</body>
    </html>
  );
}

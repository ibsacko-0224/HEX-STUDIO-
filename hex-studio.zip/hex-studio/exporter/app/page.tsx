import { Site } from '../../src/shared/render/Site';
import { loadSite } from './load-site';

export default function Page() {
  const { doc, assets } = loadSite();
  return <Site doc={doc} assets={assets} mediaBase="/media" />;
}

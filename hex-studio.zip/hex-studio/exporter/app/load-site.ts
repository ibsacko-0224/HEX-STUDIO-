import fs from 'node:fs';
import type { SiteDoc } from '../../src/shared/site';

export function loadSite(): SiteDoc {
  const file = process.env.PROJECT_FILE;
  if (!file) throw new Error('PROJECT_FILE manquant : ce dossier est lancé par Hex Studio (bouton Publier).');
  return JSON.parse(fs.readFileSync(file, 'utf8')) as SiteDoc;
}

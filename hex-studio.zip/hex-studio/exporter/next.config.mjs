/** @type {import('next').NextConfig} */
// Générateur du SITE statique : lit .build/<slug>/site.json (variable PROJECT_FILE) et produit out/.
const nextConfig = {
  output: 'export',
  images: { unoptimized: true }, // les variantes responsive sont déjà générées à l'import
  reactStrictMode: true,
  trailingSlash: false,
  experimental: { externalDir: true }, // partage src/shared avec l'éditeur
};
export default nextConfig;

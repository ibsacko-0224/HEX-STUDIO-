/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Modules natifs : chargés par Node, jamais empaquetés.
  serverExternalPackages: ['better-sqlite3', 'sharp'],
  // L'éditeur tourne en local (serveur Next). Seul le SITE généré est statique (voir exporter/).
  experimental: { externalDir: true },
};
export default nextConfig;

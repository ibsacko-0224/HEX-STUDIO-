/** @type {import('tailwindcss').Config} */
module.exports = {
  presets: [require('./tailwind.preset.cjs')],
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      // Palette de l'interface d'édition (distincte des jetons du site produit).
      colors: {
        ed: { bg: '#E7EAF0', panel: '#FFFFFF', ink: '#14213D', mute: '#5A6578', line: '#D3D9E4', accent: '#5B3DF5', warn: '#B45309' },
      },
      boxShadow: { frame: '0 1px 2px rgb(20 33 61 / .08), 0 12px 40px rgb(20 33 61 / .14)' },
    },
  },
};

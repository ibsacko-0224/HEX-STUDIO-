import { uid } from './lib';
import type { ProjectDoc, Section, SectionType } from './schema';

const plain = { align: 'left', background: 'plain' } as const;
const tint = { align: 'left', background: 'tint' } as const;

export function newSection(type: SectionType): Section {
  const id = uid(10);
  switch (type) {
    case 'header':
      return {
        id, type, style: plain,
        eyebrow: 'Nouveau', title: 'Votre projet, en ligne dès ce soir',
        subtitle: 'Assemblez une page claire à partir de blocs, modifiez le texte directement dessus, puis publiez sur votre propre serveur.',
        ctaLabel: 'Commencer', ctaHref: '#pricing', secondaryLabel: 'Voir les fonctionnalités', secondaryHref: '#features',
        imageId: null, imageAlt: '',
      };
    case 'proof':
      return {
        id, type, style: tint,
        title: 'Ils publient déjà avec nous', subtitle: '',
        stats: [
          { value: '12 000', label: 'pages publiées' },
          { value: '4,8/5', label: 'note moyenne' },
          { value: '3 min', label: 'pour une première page' },
        ],
        quotes: [
          { quote: 'Ma page était en ligne avant la fin du café. Rien à installer côté hébergeur.', author: 'Camille Roux', role: 'Fondatrice, Atelier Brume' },
          { quote: 'Je garde mes fichiers chez moi et je déploie quand je veux.', author: 'Malik Benali', role: 'Développeur indépendant' },
        ],
      };
    case 'features':
      return {
        id, type, style: plain,
        title: 'Tout ce qu’il faut, rien de superflu', subtitle: 'Un éditeur pensé pour une seule chose : sortir une bonne page d’accueil.',
        items: [
          { icon: 'layers', title: 'Des blocs prêts à l’emploi', text: 'En-tête, preuve, fonctionnalités, tarifs, FAQ et pied de page s’empilent dans l’ordre voulu.' },
          { icon: 'shield', title: 'Vos données restent chez vous', text: 'Tout est stocké en local. Exportez un fichier JSON quand vous voulez.' },
          { icon: 'bolt', title: 'Publication statique', text: 'Un dossier de fichiers simples, rapide à servir et facile à héberger.' },
        ],
      };
    case 'pricing':
      return {
        id, type, style: tint,
        title: 'Des tarifs lisibles', subtitle: 'Changez les montants, les listes et les boutons directement ici.',
        plans: [
          { name: 'Découverte', price: '0 €', period: 'pour toujours', description: 'Pour tester l’idée.', features: ['1 page', 'Export statique'], ctaLabel: 'Essayer', ctaHref: '#', highlighted: false },
          { name: 'Pro', price: '19 €', period: 'par mois', description: 'Pour lancer sérieusement.', features: ['Pages illimitées', 'Domaine personnalisé', 'Support par e-mail'], ctaLabel: 'Choisir Pro', ctaHref: '#', highlighted: true },
          { name: 'Équipe', price: '49 €', period: 'par mois', description: 'Pour travailler à plusieurs.', features: ['Tout Pro', '5 personnes', 'Relectures'], ctaLabel: 'Nous écrire', ctaHref: 'mailto:bonjour@example.com', highlighted: false },
        ],
      };
    case 'faq':
      return {
        id, type, style: plain,
        title: 'Questions fréquentes', subtitle: '',
        items: [
          { q: 'Où sont stockées mes données ?', a: 'Sur votre machine, dans une base SQLite locale. Rien n’est envoyé à un service tiers.' },
          { q: 'Comment publier mon site ?', a: 'Construisez le site statique puis envoyez-le sur votre serveur avec rsync via SSH.' },
          { q: 'Puis-je sauvegarder mon projet ?', a: 'Oui : l’export JSON contient le contenu, le thème et les images originales.' },
        ],
      };
    case 'footer':
      return {
        id, type, style: tint,
        brand: 'Votre marque', tagline: 'Une phrase simple qui dit ce que vous faites.',
        copyright: '© 2026 Votre marque. Tous droits réservés.',
        links: [{ label: 'Contact', href: 'mailto:bonjour@example.com' }, { label: 'Mentions légales', href: '/mentions' }],
      };
  }
}

export function starterDoc(): ProjectDoc {
  return {
    lang: 'fr',
    seo: { title: 'Ma page d’accueil', description: 'Une page d’accueil simple, rapide et publiée sur mon propre serveur.' },
    theme: { palette: 'indigo', font: 'sans', radius: 'md', spacing: 'cozy', mode: 'light' },
    sections: (['header', 'proof', 'features', 'pricing', 'faq', 'footer'] as const).map(newSection),
  };
}

'use client';
import type { ReactNode } from 'react';
import type { Section } from '../schema';
import { cx, getIn, type Path } from '../lib';
import { Img, Txt, useRender } from './ctx';

type S<T extends Section['type']> = Extract<Section, { type: T }>;
type Tx = (path: Path, as: string, className?: string, multiline?: boolean, max?: number) => ReactNode;

const onBrand = (s: Section) => s.style.background === 'brand';
const muted = (s: Section) => (onBrand(s) ? 'text-brand-fg/80' : 'text-muted');
const line = (s: Section) => (onBrand(s) ? 'border-brand-fg/30' : 'border-border');
const card = (s: Section) => (onBrand(s) ? 'border-brand-fg/30' : 'border-border bg-bg');

function makeT(s: Section): Tx {
  return (path, as, className, multiline, max) => (
    <Txt sid={s.id} path={path} value={String(getIn(s, path) ?? '')} as={as} className={className} multiline={multiline} max={max} />
  );
}

const ICON: Record<string, ReactNode> = {
  bolt: <path d="M13 2 4 14h7l-1 8 9-12h-7z" />,
  shield: <path d="M12 3 4 6v6c0 5 3.4 8.2 8 9 4.6-.8 8-4 8-9V6z" />,
  chart: <path d="M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-3" />,
  globe: (<><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></>),
  heart: <path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" />,
  layers: <path d="m12 3 9 5-9 5-9-5zM3 13l9 5 9-5" />,
};
const Svg = ({ children, className = 'h-5 w-5' }: { children: ReactNode; className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={className}>
    {children}
  </svg>
);

function Shell({ s, anchor, compact, children }: { s: Section; anchor?: string; compact?: boolean; children: ReactNode }) {
  const { editor } = useRender();
  const surface = s.style.background === 'brand' ? 'bg-brand text-brand-fg' : s.style.background === 'tint' ? 'bg-tint text-fg' : 'bg-bg text-fg';
  const selected = editor?.selectedId === s.id;
  return (
    <section
      id={anchor}
      data-section={s.id}
      data-type={s.type}
      onClickCapture={editor ? () => editor.select(s.id) : undefined}
      className={cx('relative', surface, selected && 'outline outline-2 -outline-offset-2 outline-[#5B3DF5]')}
    >
      <div
        className={cx(
          'mx-auto max-w-6xl px-5 @2xl:px-10',
          compact ? 'py-10 @3xl:py-14' : 'py-[calc(var(--py)*.6)] @3xl:py-[var(--py)]',
          s.style.align === 'center' && 'text-center',
        )}
      >
        {children}
      </div>
    </section>
  );
}

function Head({ s, T }: { s: Exclude<Section, S<'header'> | S<'footer'>>; T: Tx }) {
  const { editor } = useRender();
  const center = s.style.align === 'center';
  const hasSub = s.subtitle !== '' || !!editor;
  return (
    <div className={cx('mb-10 max-w-2xl @3xl:mb-12', center && 'mx-auto')}>
      {T(['title'], 'h2', 'font-head text-3xl font-semibold leading-tight tracking-tight text-balance @3xl:text-4xl')}
      {hasSub && T(['subtitle'], 'p', cx('mt-3 text-lg leading-relaxed', muted(s)), true)}
    </div>
  );
}

function Btn({ s, T, path, href, kind, surface }: {
  s: Section; T: Tx; path: Path; href: string; kind: 'primary' | 'outline'; surface: 'light' | 'brand';
}) {
  const { editor } = useRender();
  if (!editor && !getIn(s, path)) return null;
  const tone =
    kind === 'primary'
      ? surface === 'brand' ? 'bg-brand-fg text-brand' : 'bg-brand text-brand-fg'
      : surface === 'brand' ? 'border border-brand-fg/50 text-brand-fg' : 'border border-border text-fg hover:bg-tint';
  const cls = cx(
    'inline-flex items-center justify-center rounded-token px-5 py-3 text-base font-medium transition-colors hover:opacity-90',
    'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-current',
    tone,
  );
  const label = T(path, 'span');
  return editor ? <span className={cls}>{label}</span> : <a href={href || '#'} className={cls}>{label}</a>;
}

function HeaderView({ s, anchor }: { s: S<'header'>; anchor?: string }) {
  const T = makeT(s);
  const center = s.style.align === 'center';
  const surface = onBrand(s) ? 'brand' : 'light';
  return (
    <Shell s={s} anchor={anchor}>
      <div className={cx('grid items-center gap-12', s.imageId && '@4xl:grid-cols-2')}>
        <div className={cx(center && !s.imageId && 'mx-auto max-w-3xl')}>
          {T(['eyebrow'], 'p', cx('mb-4 text-sm font-semibold', onBrand(s) ? 'text-brand-fg/80' : 'text-brand'), false, 80)}
          {T(['title'], 'h1', 'font-head text-4xl font-semibold leading-[1.08] tracking-tight text-balance @2xl:text-5xl @4xl:text-6xl', false, 160)}
          {T(['subtitle'], 'p', cx('mt-5 max-w-xl text-lg leading-relaxed @2xl:text-xl', muted(s), center && !s.imageId && 'mx-auto'), true)}
          <div className={cx('mt-8 flex flex-wrap gap-3', center && !s.imageId && 'justify-center')}>
            <Btn s={s} T={T} path={['ctaLabel']} href={s.ctaHref} kind="primary" surface={surface} />
            <Btn s={s} T={T} path={['secondaryLabel']} href={s.secondaryHref} kind="outline" surface={surface} />
          </div>
        </div>
        {s.imageId && (
          <div className="overflow-hidden rounded-token border border-border">
            <Img id={s.imageId} alt={s.imageAlt} eager sizes="(min-width: 896px) 560px, 100vw" />
          </div>
        )}
      </div>
    </Shell>
  );
}

function ProofView({ s, anchor }: { s: S<'proof'>; anchor?: string }) {
  const T = makeT(s);
  return (
    <Shell s={s} anchor={anchor}>
      <Head s={s} T={T} />
      {s.stats.length > 0 && (
        <div className={cx('grid grid-cols-2 gap-x-6 gap-y-8 @3xl:grid-cols-4', s.quotes.length > 0 && 'mb-14')}>
          {s.stats.map((it, i) => (
            <div key={i} className={cx('border-t pt-4', line(s))}>
              {T(['stats', i, 'value'], 'p', 'font-head text-4xl font-semibold tracking-tight', false, 24)}
              {T(['stats', i, 'label'], 'p', cx('mt-1', muted(s)), false, 80)}
            </div>
          ))}
        </div>
      )}
      {s.quotes.length > 0 && (
        <div className="grid gap-6 text-left @2xl:grid-cols-2 @4xl:grid-cols-3">
          {s.quotes.map((q, i) => (
            <figure key={i} className={cx('flex flex-col justify-between gap-6 rounded-token border p-6', card(s))}>
              <blockquote>{T(['quotes', i, 'quote'], 'p', 'text-lg leading-relaxed', true)}</blockquote>
              <figcaption>
                {T(['quotes', i, 'author'], 'p', 'font-semibold', false, 80)}
                {T(['quotes', i, 'role'], 'p', cx('text-sm', muted(s)), false, 120)}
              </figcaption>
            </figure>
          ))}
        </div>
      )}
    </Shell>
  );
}

function FeaturesView({ s, anchor }: { s: S<'features'>; anchor?: string }) {
  const T = makeT(s);
  return (
    <Shell s={s} anchor={anchor}>
      <Head s={s} T={T} />
      <div className="grid gap-x-10 gap-y-10 text-left @2xl:grid-cols-2 @4xl:grid-cols-3">
        {s.items.map((it, i) => (
          <div key={i} className={cx('border-t pt-5', line(s))}>
            <span className={cx('mb-4 grid h-10 w-10 place-items-center rounded-token', onBrand(s) ? 'bg-brand-fg/15 text-brand-fg' : 'bg-brand/10 text-brand')}>
              <Svg>{ICON[it.icon]}</Svg>
            </span>
            {T(['items', i, 'title'], 'h3', 'font-head text-xl font-semibold', false, 80)}
            {T(['items', i, 'text'], 'p', cx('mt-2 leading-relaxed', muted(s)), true, 300)}
          </div>
        ))}
      </div>
    </Shell>
  );
}

function PricingView({ s, anchor }: { s: S<'pricing'>; anchor?: string }) {
  const T = makeT(s);
  const cols = s.plans.length >= 3 ? '@3xl:grid-cols-3' : s.plans.length === 2 ? '@3xl:grid-cols-2' : '';
  return (
    <Shell s={s} anchor={anchor}>
      <Head s={s} T={T} />
      <div className={cx('grid items-stretch gap-6 text-left', cols)}>
        {s.plans.map((p, i) => {
          const hl = p.highlighted;
          const planCls = hl ? (onBrand(s) ? 'border-transparent bg-bg text-fg' : 'border-transparent bg-brand text-brand-fg') : card(s);
          const soft = hl ? (onBrand(s) ? 'text-muted' : 'text-brand-fg/80') : muted(s);
          return (
            <div key={i} className={cx('flex flex-col rounded-token border p-7', planCls)}>
              {T(['plans', i, 'name'], 'h3', 'font-head text-xl font-semibold', false, 40)}
              <p className="mt-4 flex flex-wrap items-baseline gap-x-2">
                {T(['plans', i, 'price'], 'span', 'font-head text-4xl font-semibold tracking-tight', false, 24)}
                {T(['plans', i, 'period'], 'span', cx('text-sm', soft), false, 30)}
              </p>
              {T(['plans', i, 'description'], 'p', cx('mt-2', soft), true, 160)}
              <ul className="my-6 flex-1 space-y-2.5">
                {p.features.map((f, j) => (
                  <li key={j} className="flex gap-2.5">
                    <Svg className="mt-0.5 h-5 w-5 shrink-0"><path d="m5 12.5 4.5 4.5L19 7.5" /></Svg>
                    {T(['plans', i, 'features', j], 'span', '', false, 120)}
                  </li>
                ))}
              </ul>
              <Btn s={s} T={T} path={['plans', i, 'ctaLabel']} href={p.ctaHref} kind={hl ? 'primary' : 'outline'}
                surface={hl ? (onBrand(s) ? 'light' : 'brand') : onBrand(s) ? 'brand' : 'light'} />
            </div>
          );
        })}
      </div>
    </Shell>
  );
}

function FaqView({ s, anchor }: { s: S<'faq'>; anchor?: string }) {
  const T = makeT(s);
  const { editor } = useRender();
  return (
    <Shell s={s} anchor={anchor}>
      <Head s={s} T={T} />
      <div className={cx('mx-auto max-w-3xl border-b text-left', line(s))}>
        {s.items.map((it, i) =>
          editor ? (
            <div key={i} className={cx('border-t py-5', line(s))}>
              {T(['items', i, 'q'], 'h3', 'text-lg font-medium', false, 200)}
              {T(['items', i, 'a'], 'p', cx('mt-2 leading-relaxed', muted(s)), true, 1000)}
            </div>
          ) : (
            <details key={i} className={cx('group border-t py-5', line(s))}>
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-lg font-medium [&::-webkit-details-marker]:hidden">
                {T(['items', i, 'q'], 'span')}
                <span aria-hidden="true" className="text-2xl leading-none transition-transform group-open:rotate-45">+</span>
              </summary>
              {T(['items', i, 'a'], 'p', cx('mt-3 leading-relaxed', muted(s)), true)}
            </details>
          ),
        )}
      </div>
    </Shell>
  );
}

function FooterView({ s, anchor }: { s: S<'footer'>; anchor?: string }) {
  const T = makeT(s);
  const { editor } = useRender();
  return (
    <Shell s={s} anchor={anchor} compact>
      <div className="flex flex-col gap-8 text-left @2xl:flex-row @2xl:items-start @2xl:justify-between">
        <div className="max-w-sm">
          {T(['brand'], 'p', 'font-head text-xl font-semibold', false, 60)}
          {T(['tagline'], 'p', cx('mt-2', muted(s)), true, 200)}
        </div>
        <nav aria-label="Pied de page">
          <ul className="flex flex-wrap gap-x-6 gap-y-3">
            {s.links.map((l, i) => (
              <li key={i}>
                {editor ? <span>{T(['links', i, 'label'], 'span', '', false, 40)}</span> : (
                  <a href={l.href || '#'} className="underline-offset-4 hover:underline">{T(['links', i, 'label'], 'span')}</a>
                )}
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className={cx('mt-10 border-t pt-6 text-left text-sm', line(s), muted(s))}>{T(['copyright'], 'p', '', false, 120)}</div>
    </Shell>
  );
}

export function SectionView({ s, anchor }: { s: Section; anchor?: string }) {
  switch (s.type) {
    case 'header': return <HeaderView s={s} anchor={anchor} />;
    case 'proof': return <ProofView s={s} anchor={anchor} />;
    case 'features': return <FeaturesView s={s} anchor={anchor} />;
    case 'pricing': return <PricingView s={s} anchor={anchor} />;
    case 'faq': return <FaqView s={s} anchor={anchor} />;
    case 'footer': return <FooterView s={s} anchor={anchor} />;
  }
}

'use client';
import { useMemo } from 'react';
import type { ProjectDoc } from '../schema';
import type { SiteAsset } from '../site';
import { RenderProvider, type EditorBridge } from './ctx';
import { SectionView } from './sections';

/** Rendu unique du site : même composant dans l'éditeur (editor défini) et dans l'export statique. */
export function Site({ doc, assets, mediaBase, editor }: {
  doc: ProjectDoc; assets: SiteAsset[]; mediaBase: string; editor?: EditorBridge;
}) {
  const map = useMemo(() => Object.fromEntries(assets.map((a) => [a.id, a])), [assets]);
  const seen = new Set<string>();
  const t = doc.theme;
  return (
    <RenderProvider value={{ assets: map, mediaBase, editor }}>
      <div
        data-site=""
        data-editing={editor ? '' : undefined}
        data-palette={t.palette}
        data-font={t.font}
        data-radius={t.radius}
        data-spacing={t.spacing}
        data-mode={t.mode}
        className="@container min-h-full bg-bg font-body text-fg antialiased break-words"
      >
        <main>
          {doc.sections.map((s) => {
            const first = !seen.has(s.type);
            seen.add(s.type);
            return <SectionView key={s.id} s={s} anchor={first ? s.type : undefined} />;
          })}
        </main>
      </div>
    </RenderProvider>
  );
}

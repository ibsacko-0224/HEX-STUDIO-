'use client';
import { createContext, createElement, useContext, type ClipboardEvent, type KeyboardEvent } from 'react';
import { cx, type Path } from '../lib';
import type { SiteAsset } from '../site';

/** Pont d'édition : absent sur le site exporté, présent dans l'éditeur. */
export type EditorBridge = {
  selectedId: string | null;
  select(id: string): void;
  commit(sectionId: string, path: Path, value: string): void;
};
export type RenderValue = { assets: Record<string, SiteAsset>; mediaBase: string; editor?: EditorBridge };

const Ctx = createContext<RenderValue>({ assets: {}, mediaBase: '/media' });
export const RenderProvider = Ctx.Provider;
export const useRender = () => useContext(Ctx);

type TxtProps = {
  sid: string; path: Path; value: string; as?: string; className?: string;
  multiline?: boolean; max?: number; placeholder?: string;
};

/** Texte : statique sur le site, modifiable en ligne dans l'éditeur (validation à la perte de focus). */
export function Txt({ sid, path, value, as = 'span', className, multiline = false, max = 400, placeholder }: TxtProps) {
  const { editor } = useRender();
  if (!editor) return value ? createElement(as, { className }, value) : null;
  return createElement(
    as,
    {
      className,
      contentEditable: true,
      suppressContentEditableWarning: true,
      spellCheck: true,
      'data-placeholder': placeholder ?? 'Écrire ici…',
      onBlur: (e: { currentTarget: HTMLElement }) => {
        let v = e.currentTarget.innerText;
        v = multiline ? v.replace(/\n{3,}/g, '\n\n') : v.replace(/\s*\n+\s*/g, ' ');
        v = v.trim().slice(0, max);
        if (v !== value) editor.commit(sid, path, v);
      },
      onKeyDown: (e: KeyboardEvent<HTMLElement>) => {
        if (e.key === 'Escape' || (e.key === 'Enter' && !multiline)) {
          e.preventDefault();
          e.currentTarget.blur();
        }
      },
      onPaste: (e: ClipboardEvent<HTMLElement>) => {
        e.preventDefault();
        const t = e.clipboardData.getData('text/plain');
        document.execCommand('insertText', false, multiline ? t : t.replace(/\s*\n+\s*/g, ' '));
      },
    },
    value,
  );
}

/** Image responsive : srcset généré à l'import, dimensions explicites (pas de saut de mise en page). */
export function Img({ id, alt, className, sizes = '100vw', eager = false }: {
  id: string; alt: string; className?: string; sizes?: string; eager?: boolean;
}) {
  const { assets, mediaBase } = useRender();
  const a = assets[id];
  if (!a || a.variants.length === 0) {
    return (
      <div className={cx('grid aspect-[4/3] place-items-center border border-dashed border-border bg-tint text-sm text-muted', className)}>
        Image introuvable
      </div>
    );
  }
  const vs = [...a.variants].sort((x, y) => x.w - y.w);
  const big = vs[vs.length - 1];
  const mid = vs.find((v) => v.w >= 960) ?? big;
  return (
    <img
      src={`${mediaBase}/${mid.file}`}
      srcSet={vs.map((v) => `${mediaBase}/${v.file} ${v.w}w`).join(', ')}
      sizes={sizes}
      width={big.w}
      height={big.h}
      alt={alt}
      loading={eager ? 'eager' : 'lazy'}
      decoding="async"
      className={cx('h-auto w-full object-cover', className)}
    />
  );
}

import type { ProjectDoc, SectionType } from './schema';

export const PALETTE_SWATCH: Record<ProjectDoc['theme']['palette'], { hex: string; label: string }> = {
  indigo: { hex: '#4F46E5', label: 'Indigo' },
  emerald: { hex: '#057A55', label: 'Émeraude' },
  rose: { hex: '#BE123C', label: 'Rose' },
  amber: { hex: '#B45309', label: 'Ambre' },
  ocean: { hex: '#0E7490', label: 'Océan' },
  slate: { hex: '#334155', label: 'Ardoise' },
};

export const SECTION_META: Record<SectionType, { label: string; hint: string }> = {
  header: { label: 'En-tête', hint: 'Titre, texte, boutons et image' },
  proof: { label: 'Preuve', hint: 'Chiffres et témoignages' },
  features: { label: 'Fonctionnalités', hint: 'Grille de bénéfices avec icônes' },
  pricing: { label: 'Tarifs', hint: 'Jusqu’à 4 formules' },
  faq: { label: 'FAQ', hint: 'Questions et réponses dépliables' },
  footer: { label: 'Pied de page', hint: 'Marque, liens, mentions' },
};

import { z } from 'zod';
import { isSafeHref } from './lib';

// Jetons de design : seules ces valeurs existent. Aucun CSS libre.
export const PALETTES = ['indigo', 'emerald', 'rose', 'amber', 'ocean', 'slate'] as const;
export const FONTS = ['sans', 'editorial', 'mono'] as const;
export const RADII = ['none', 'md', 'xl'] as const;
export const SPACINGS = ['compact', 'cozy', 'airy'] as const;
export const MODES = ['light', 'dark'] as const;
export const ICONS = ['bolt', 'shield', 'chart', 'globe', 'heart', 'layers'] as const;
export const SECTION_TYPES = ['header', 'proof', 'features', 'pricing', 'faq', 'footer'] as const;

const txt = (max: number) => z.string().max(max);
const href = z.string().max(500).refine(isSafeHref, 'Lien invalide (http, https, mailto, tel, #ancre ou /chemin)');
const id = z.string().regex(/^[a-z0-9]{6,24}$/, 'Identifiant invalide');
const style = z.object({ align: z.enum(['left', 'center']), background: z.enum(['plain', 'tint', 'brand']) });
const base = { id, style };

export const sectionSchema = z.discriminatedUnion('type', [
  z.object({
    ...base, type: z.literal('header'),
    eyebrow: txt(80), title: txt(160), subtitle: txt(400),
    ctaLabel: txt(40), ctaHref: href, secondaryLabel: txt(40), secondaryHref: href,
    imageId: id.nullable(), imageAlt: txt(200),
  }),
  z.object({
    ...base, type: z.literal('proof'),
    title: txt(160), subtitle: txt(400),
    stats: z.array(z.object({ value: txt(24), label: txt(80) })).max(8),
    quotes: z.array(z.object({ quote: txt(400), author: txt(80), role: txt(120) })).max(9),
  }),
  z.object({
    ...base, type: z.literal('features'),
    title: txt(160), subtitle: txt(400),
    items: z.array(z.object({ icon: z.enum(ICONS), title: txt(80), text: txt(300) })).max(12),
  }),
  z.object({
    ...base, type: z.literal('pricing'),
    title: txt(160), subtitle: txt(400),
    plans: z.array(z.object({
      name: txt(40), price: txt(24), period: txt(30), description: txt(160),
      features: z.array(txt(120)).max(12), ctaLabel: txt(40), ctaHref: href, highlighted: z.boolean(),
    })).max(4),
  }),
  z.object({
    ...base, type: z.literal('faq'),
    title: txt(160), subtitle: txt(400),
    items: z.array(z.object({ q: txt(200), a: txt(1000) })).max(20),
  }),
  z.object({
    ...base, type: z.literal('footer'),
    brand: txt(60), tagline: txt(200), copyright: txt(120),
    links: z.array(z.object({ label: txt(40), href })).max(12),
  }),
]);

export const projectDocSchema = z.object({
  lang: z.string().regex(/^[a-z]{2}(-[A-Za-z]{2})?$/, 'Code langue invalide (ex. fr, en-GB)'),
  seo: z.object({ title: txt(120), description: txt(300) }),
  theme: z.object({
    palette: z.enum(PALETTES), font: z.enum(FONTS), radius: z.enum(RADII),
    spacing: z.enum(SPACINGS), mode: z.enum(MODES),
  }),
  sections: z.array(sectionSchema).max(40),
});

export const projectNameSchema = z.string().trim().min(1, 'Le nom est requis').max(80, 'Nom trop long (80 max)');

/** Format d'export JSON portable (médias originaux en base64). */
export const exportFileSchema = z.object({
  format: z.literal('central-hex-site'),
  version: z.literal(1),
  exportedAt: z.string(),
  project: z.object({ name: projectNameSchema, doc: projectDocSchema }),
  media: z.array(z.object({ id, name: z.string().max(200), data: z.string() })).max(200),
});

export type Section = z.infer<typeof sectionSchema>;
export type SectionType = Section['type'];
export type ProjectDoc = z.infer<typeof projectDocSchema>;
export type ExportFile = z.infer<typeof exportFileSchema>;

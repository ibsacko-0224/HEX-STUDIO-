// Utilitaires purs partagés entre l'éditeur, le serveur et le site exporté.

export const cx = (...a: Array<string | false | null | undefined>) => a.filter(Boolean).join(' ');

export type Path = ReadonlyArray<string | number>;

export function getIn(obj: unknown, path: Path): unknown {
  let cur: any = obj;
  for (const k of path) {
    if (cur == null) return undefined;
    cur = cur[k];
  }
  return cur;
}

/** Mise à jour immuable à un chemin donné. */
export function setIn<T>(obj: T, path: Path, value: unknown): T {
  if (path.length === 0) return value as T;
  const [head, ...rest] = path;
  const src: any = obj;
  const copy: any = Array.isArray(src) ? [...src] : { ...(src ?? {}) };
  copy[head] = setIn(src?.[head], rest, value);
  return copy;
}

export function moveItem<T>(arr: readonly T[], from: number, to: number): T[] {
  if (from === to || from < 0 || to < 0 || from >= arr.length || to >= arr.length) return [...arr];
  const next = [...arr];
  const [it] = next.splice(from, 1);
  next.splice(to, 0, it);
  return next;
}

const ALPHABET = 'abcdefghijklmnopqrstuvwxyz0123456789';
export function uid(len = 12): string {
  const a = new Uint8Array(len);
  globalThis.crypto.getRandomValues(a);
  return Array.from(a, (b) => ALPHABET[b % ALPHABET.length]).join('');
}

export function slugify(input: string, max = 60): string {
  const s = input
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, max)
    .replace(/-+$/, '');
  return s || 'site';
}

/** Nom de fichier sûr : jamais de chemin, jamais de caractères spéciaux. */
export function safeFilename(name: string): { base: string; ext: string } {
  const last = name.split(/[\\/]/).pop() ?? '';
  const dot = last.lastIndexOf('.');
  const stem = dot > 0 ? last.slice(0, dot) : last;
  const ext = dot > 0 ? last.slice(dot + 1).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 5) : '';
  return { base: slugify(stem || 'image', 40), ext };
}

const HREF = /^(?:https?:\/\/[^\s<>"']+|mailto:[^\s@<>]+@[^\s@<>]+|tel:[+\d\s().-]{3,30}|#[\w-]*|\/(?!\/)[^\s<>"']*)$/i;
/** Liens autorisés : http(s), mailto, tel, #ancre, /chemin. Jamais javascript: ni data:. */
export const isSafeHref = (v: string): boolean => v === '' || HREF.test(v);

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} o`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(0)} Ko`;
  return `${(n / 1024 ** 2).toFixed(1)} Mo`;
}

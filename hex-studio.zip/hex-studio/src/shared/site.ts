import type { ProjectDoc } from './schema';

export type Variant = { w: number; h: number; file: string };
/** Ce que le rendu doit savoir d'une image. */
export type SiteAsset = { id: string; variants: Variant[] };
/** Métadonnées complètes renvoyées par l'API à l'éditeur. */
export type AssetMeta = SiteAsset & { name: string; width: number; height: number };
/** Fichier d'entrée du générateur statique (exporter/). */
export type SiteDoc = { name: string; slug: string; doc: ProjectDoc; assets: SiteAsset[] };

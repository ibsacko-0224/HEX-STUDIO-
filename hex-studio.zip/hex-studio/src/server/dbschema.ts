import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';
import type { ProjectDoc } from '../shared/schema';
import type { Variant } from '../shared/site';

export const projects = sqliteTable('projects', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull().unique(),
  doc: text('doc', { mode: 'json' }).$type<ProjectDoc>().notNull(),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
});

export const assets = sqliteTable('assets', {
  id: text('id').primaryKey(),
  projectId: text('project_id').notNull().references(() => projects.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  original: text('original').notNull(),
  variants: text('variants', { mode: 'json' }).$type<Variant[]>().notNull(),
  createdAt: integer('created_at').notNull(),
});

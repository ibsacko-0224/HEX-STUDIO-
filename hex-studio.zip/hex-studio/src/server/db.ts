import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { drizzle, type BetterSQLite3Database } from 'drizzle-orm/better-sqlite3';
import * as schema from './dbschema';

type Db = BetterSQLite3Database<typeof schema>;
const g = globalThis as unknown as { __hexDb?: { dir: string; db: Db } };

/** Dossier des données locales (SQLite + médias). Lu à chaque appel pour rester testable. */
export const dataDir = () => path.resolve(process.env.DATA_DIR || './data');

/** Schéma créé de façon idempotente au premier accès : aucune étape de migration manuelle. */
const DDL = `
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  doc TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS assets (
  id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  original TEXT NOT NULL,
  variants TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS assets_project ON assets(project_id);
`;

export function getDb(): Db {
  const dir = dataDir();
  if (g.__hexDb?.dir === dir) return g.__hexDb.db;
  fs.mkdirSync(dir, { recursive: true });
  const sqlite = new Database(path.join(dir, 'hex-studio.db'));
  sqlite.pragma('journal_mode = WAL');
  sqlite.pragma('foreign_keys = ON');
  sqlite.exec(DDL);
  const db = drizzle(sqlite, { schema });
  g.__hexDb = { dir, db };
  return db;
}

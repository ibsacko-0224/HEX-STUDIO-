import fs from 'node:fs';
import path from 'node:path';
import { desc, eq } from 'drizzle-orm';
import { slugify, uid } from '../shared/lib';
import { starterDoc } from '../shared/defaults';
import {
  exportFileSchema, projectDocSchema, projectNameSchema,
  type ExportFile, type ProjectDoc,
} from '../shared/schema';
import type { AssetMeta } from '../shared/site';
import { getDb } from './db';
import { AppError } from './http';
import { assets, projects } from './dbschema';
import { addAsset, mediaDir, MAX_UPLOAD_BYTES, toMeta } from './media';

export type ProjectData = { id: string; name: string; slug: string; doc: ProjectDoc; assets: AssetMeta[]; updatedAt: number };

export function assertId(id: string): void {
  if (!/^[a-z0-9]{6,24}$/.test(id)) throw new AppError(400, 'bad_id', 'Identifiant invalide.');
}

function uniqueSlug(name: string): string {
  const db = getDb();
  const base = slugify(name);
  let slug = base;
  for (let i = 2; db.select().from(projects).where(eq(projects.slug, slug)).get(); i++) slug = `${base}-${i}`;
  return slug;
}

export function listProjects() {
  return getDb().select().from(projects).orderBy(desc(projects.updatedAt)).all()
    .map((p) => ({ id: p.id, name: p.name, slug: p.slug, updatedAt: p.updatedAt, sections: p.doc.sections.length }));
}

export function getProject(id: string): ProjectData | null {
  assertId(id);
  const db = getDb();
  const row = db.select().from(projects).where(eq(projects.id, id)).get();
  if (!row) return null;
  const list = db.select().from(assets).where(eq(assets.projectId, id)).all().map(toMeta);
  return { id: row.id, name: row.name, slug: row.slug, doc: row.doc, assets: list, updatedAt: row.updatedAt };
}

export function requireProject(id: string): ProjectData {
  const p = getProject(id);
  if (!p) throw new AppError(404, 'not_found', 'Projet introuvable.');
  return p;
}

export function createProject(rawName: unknown, doc: ProjectDoc = starterDoc()): ProjectData {
  const name = projectNameSchema.parse(rawName);
  const parsed = projectDocSchema.parse(doc);
  const id = uid(12);
  const now = Date.now();
  getDb().insert(projects).values({ id, name, slug: uniqueSlug(name), doc: parsed, createdAt: now, updatedAt: now }).run();
  return requireProject(id);
}

export function saveProject(id: string, input: { name?: unknown; doc: unknown }): { updatedAt: number } {
  const current = requireProject(id);
  const doc = projectDocSchema.parse(input.doc);
  const name = input.name === undefined ? current.name : projectNameSchema.parse(input.name);
  const known = new Set(current.assets.map((a) => a.id));
  for (const s of doc.sections) {
    if (s.type === 'header' && s.imageId && !known.has(s.imageId)) {
      throw new AppError(400, 'unknown_media', 'Une image référencée n’existe plus dans ce projet.');
    }
  }
  const updatedAt = Date.now();
  getDb().update(projects).set({ name, doc, updatedAt }).where(eq(projects.id, id)).run();
  return { updatedAt };
}

export function deleteProject(id: string): void {
  requireProject(id);
  getDb().delete(projects).where(eq(projects.id, id)).run();
  fs.rmSync(mediaDir(id), { recursive: true, force: true });
}

/** Export JSON portable : contenu + thème + images originales (base64). */
export function exportProject(id: string): ExportFile {
  const p = requireProject(id);
  const rows = getDb().select().from(assets).where(eq(assets.projectId, id)).all();
  return {
    format: 'central-hex-site',
    version: 1,
    exportedAt: new Date().toISOString(),
    project: { name: p.name, doc: p.doc },
    media: rows.map((r) => ({
      id: r.id,
      name: r.name,
      data: fs.readFileSync(path.join(mediaDir(id), r.original)).toString('base64'),
    })),
  };
}

export async function importProject(raw: unknown): Promise<ProjectData> {
  const file = exportFileSchema.parse(raw);
  const created = createProject(file.project.name, { ...file.project.doc, sections: [] });
  try {
    const idMap = new Map<string, string>();
    for (const m of file.media) {
      const buf = Buffer.from(m.data, 'base64');
      if (buf.length > MAX_UPLOAD_BYTES) throw new AppError(413, 'too_large', `Le média « ${m.name} » dépasse 10 Mo.`);
      idMap.set(m.id, (await addAsset(created.id, buf, m.name)).id);
    }
    const doc: ProjectDoc = {
      ...file.project.doc,
      sections: file.project.doc.sections.map((s) =>
        s.type === 'header' ? { ...s, imageId: s.imageId ? idMap.get(s.imageId) ?? null : null } : s),
    };
    saveProject(created.id, { doc });
    return requireProject(created.id);
  } catch (e) {
    deleteProject(created.id); // pas de projet à moitié importé
    throw e;
  }
}

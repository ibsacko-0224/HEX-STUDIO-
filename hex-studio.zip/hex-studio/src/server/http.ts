import { ZodError } from 'zod';

export class AppError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

export function json(data: unknown, status = 200): Response {
  return Response.json(data, { status, headers: { 'cache-control': 'no-store' } });
}

/** Transforme toute erreur en réponse JSON propre ; ne fuit jamais de stack trace. */
export function handle<A extends unknown[]>(fn: (...a: A) => Promise<Response> | Response) {
  return async (...a: A): Promise<Response> => {
    try {
      return await fn(...a);
    } catch (e) {
      if (e instanceof AppError) return json({ error: { code: e.code, message: e.message } }, e.status);
      if (e instanceof ZodError) {
        const message = e.issues.slice(0, 3).map((i) => `${i.path.join('.') || 'valeur'} : ${i.message}`).join(' ; ');
        return json({ error: { code: 'invalid', message } }, 400);
      }
      console.error(e);
      return json({ error: { code: 'internal', message: 'Erreur interne du serveur local. Consultez le terminal.' } }, 500);
    }
  };
}

export async function readJson(req: Request, maxBytes = 2_000_000): Promise<unknown> {
  const len = Number(req.headers.get('content-length') ?? 0);
  if (len > maxBytes) throw new AppError(413, 'too_large', 'Requête trop volumineuse.');
  const text = await req.text();
  if (text.length > maxBytes) throw new AppError(413, 'too_large', 'Requête trop volumineuse.');
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    throw new AppError(400, 'bad_json', 'JSON invalide.');
  }
}

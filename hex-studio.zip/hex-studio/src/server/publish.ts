import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { SiteDoc } from '../shared/site';
import { AppError } from './http';
import { mediaDir } from './media';
import { requireProject } from './projects';

const ROOT = () => process.cwd();
let busy = false;

export type DeployResult = { ok: boolean; message: string };
export type PublishResult = {
  slug: string; outDir: string; files: number; bytes: number; durationMs: number; deploy: DeployResult | null;
};

// ───────────────────────── Processus enfants (jamais de shell)
function run(cmd: string, args: string[], opts: { cwd: string; env?: NodeJS.ProcessEnv; timeoutMs: number }) {
  return new Promise<{ code: number | null; tail: string; spawnError?: string }>((resolve) => {
    let tail = '';
    const push = (b: Buffer) => { tail = (tail + b.toString()).slice(-4000); };
    const child = spawn(cmd, args, { cwd: opts.cwd, env: { ...process.env, ...opts.env }, stdio: ['ignore', 'pipe', 'pipe'] });
    const timer = setTimeout(() => child.kill('SIGKILL'), opts.timeoutMs);
    child.stdout.on('data', push);
    child.stderr.on('data', push);
    child.on('error', (e) => { clearTimeout(timer); resolve({ code: null, tail, spawnError: e.message }); });
    child.on('close', (code) => { clearTimeout(timer); resolve({ code, tail }); });
  });
}

function stats(dir: string): { files: number; bytes: number } {
  let files = 0, bytes = 0;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { const s = stats(p); files += s.files; bytes += s.bytes; }
    else { files++; bytes += fs.statSync(p).size; }
  }
  return { files, bytes };
}

// ───────────────────────── Cible de déploiement unique : rsync via SSH, configurée par .env
export type DeployConfig = { host: string; user: string; remotePath: string; port: number; key: string };

export function readDeployConfig(env = process.env): { ok: true; config: DeployConfig } | { ok: false; reason: string } {
  const host = (env.DEPLOY_HOST ?? '').trim();
  const user = (env.DEPLOY_USER ?? '').trim();
  const remotePath = (env.DEPLOY_PATH ?? '').trim().replace(/\/+$/, '');
  if (!host || !user || !remotePath) {
    return { ok: false, reason: 'Déploiement non configuré : renseignez DEPLOY_HOST, DEPLOY_USER et DEPLOY_PATH dans .env.' };
  }
  if (!/^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$/i.test(host)) return { ok: false, reason: 'DEPLOY_HOST invalide.' };
  if (!/^[a-z_][a-z0-9_-]{0,31}$/i.test(user)) return { ok: false, reason: 'DEPLOY_USER invalide.' };
  if (!/^\/[\w./-]+$/.test(remotePath) || remotePath.includes('..') || remotePath.split('/').filter(Boolean).length < 2) {
    return { ok: false, reason: 'DEPLOY_PATH doit être un chemin absolu d’au moins deux niveaux (ex. /var/www/mon-site).' };
  }
  const port = Number(env.DEPLOY_PORT || 22);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return { ok: false, reason: 'DEPLOY_PORT invalide.' };
  const rawKey = (env.DEPLOY_SSH_KEY || '~/.ssh/id_ed25519').trim();
  if (!/^[\w./~-]+$/.test(rawKey)) return { ok: false, reason: 'DEPLOY_SSH_KEY contient des caractères non autorisés.' };
  const key = rawKey.startsWith('~') ? path.join(os.homedir(), rawKey.slice(1)) : path.resolve(rawKey);
  if (!fs.existsSync(key)) return { ok: false, reason: `Clé SSH introuvable : ${rawKey}` };
  return { ok: true, config: { host, user, remotePath, port, key } };
}

async function deploySite(dir: string): Promise<DeployResult> {
  const cfg = readDeployConfig();
  if (!cfg.ok) return { ok: false, message: cfg.reason };
  const { host, user, remotePath, port, key } = cfg.config;
  const ssh = `ssh -i ${key} -p ${port} -o BatchMode=yes -o StrictHostKeyChecking=accept-new`;
  const r = await run('rsync', ['-az', '--delete', '-e', ssh, dir + path.sep, `${user}@${host}:${remotePath}/`], { cwd: ROOT(), timeoutMs: 180_000 });
  if (r.spawnError) return { ok: false, message: `rsync est introuvable ou n’a pas pu démarrer (${r.spawnError}). Le site construit reste dans exports/.` };
  if (r.code !== 0) return { ok: false, message: `Échec du transfert (code ${r.code}). ${r.tail.trim().split('\n').slice(-3).join(' ')}` };
  return { ok: true, message: `Site envoyé vers ${user}@${host}:${remotePath}` };
}

// ───────────────────────── Publication
export async function publishProject(id: string, opts: { deploy?: boolean } = {}): Promise<PublishResult> {
  if (busy) throw new AppError(409, 'busy', 'Une publication est déjà en cours. Patientez quelques secondes.');
  busy = true;
  const t0 = Date.now();
  try {
    const p = requireProject(id);
    const exporter = path.join(ROOT(), 'exporter');
    if (!fs.existsSync(path.join(exporter, 'next.config.mjs'))) {
      throw new AppError(500, 'no_exporter', 'Dossier exporter/ introuvable. Lancez l’application depuis la racine du dépôt.');
    }

    const usedIds = new Set(p.doc.sections.flatMap((s) => (s.type === 'header' && s.imageId ? [s.imageId] : [])));
    const used = p.assets.filter((a) => usedIds.has(a.id));
    const site: SiteDoc = { name: p.name, slug: p.slug, doc: p.doc, assets: used.map((a) => ({ id: a.id, variants: a.variants })) };

    const buildDir = path.join(ROOT(), '.build', p.slug);
    fs.mkdirSync(buildDir, { recursive: true });
    const siteFile = path.join(buildDir, 'site.json');
    fs.writeFileSync(siteFile, JSON.stringify(site));

    const pub = path.join(exporter, 'public', 'media');
    fs.rmSync(pub, { recursive: true, force: true });
    fs.mkdirSync(pub, { recursive: true });
    for (const a of used) for (const v of a.variants) fs.copyFileSync(path.join(mediaDir(p.id), v.file), path.join(pub, v.file));

    fs.rmSync(path.join(exporter, 'out'), { recursive: true, force: true });
    const nextBin = path.join(ROOT(), 'node_modules', 'next', 'dist', 'bin', 'next');
    const r = await run(process.execPath, [nextBin, 'build'], {
      cwd: exporter,
      env: { PROJECT_FILE: siteFile, NEXT_TELEMETRY_DISABLED: '1', NODE_ENV: 'production' },
      timeoutMs: 240_000,
    });
    const out = path.join(exporter, 'out');
    if (r.code !== 0 || !fs.existsSync(path.join(out, 'index.html'))) {
      throw new AppError(500, 'build_failed', `La construction a échoué. Dernières lignes :\n${r.tail.trim().split('\n').slice(-12).join('\n')}`);
    }

    const exportsDir = path.resolve(process.env.EXPORTS_DIR || './exports');
    const target = path.join(exportsDir, p.slug);
    fs.rmSync(target, { recursive: true, force: true });
    fs.mkdirSync(exportsDir, { recursive: true });
    fs.cpSync(out, target, { recursive: true });

    const { files, bytes } = stats(target);
    const deploy = opts.deploy ? await deploySite(target) : null;
    return { slug: p.slug, outDir: target, files, bytes, durationMs: Date.now() - t0, deploy };
  } finally {
    busy = false;
  }
}

import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import { and, eq } from 'drizzle-orm';
import { safeFilename, uid } from '../shared/lib';
import type { AssetMeta, Variant } from '../shared/site';
import { dataDir, getDb } from './db';
import { AppError } from './http';
import { assets, projects } from './dbschema';

export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
const WIDTHS = [480, 960, 1600];
const FORMATS: Record<string, string> = { jpeg: 'jpg', png: 'png', webp: 'webp', gif: 'gif', avif: 'avif' };
const MIME: Record<string, string> = { webp: 'image/webp', jpg: 'image/jpeg', png: 'image/png', gif: 'image/gif', avif: 'image/avif' };

export const mediaDir = (projectId: string) => path.join(dataDir(), 'media', projectId);
const FILE_RE = /^[a-z0-9][a-z0-9.-]{1,100}$/;

export function toMeta(row: typeof assets.$inferSelect): AssetMeta {
  const big = [...row.variants].sort((a, b) => b.w - a.w)[0];
  return { id: row.id, name: row.name, variants: row.variants, width: big?.w ?? 0, height: big?.h ?? 0 };
}

/** Valide l'image par son contenu réel (pas par son nom ni son type MIME), puis génère les variantes responsive. */
export async function addAsset(projectId: string, input: Buffer, originalName: string): Promise<AssetMeta> {
  const db = getDb();
  if (!db.select().from(projects).where(eq(projects.id, projectId)).get()) throw new AppError(404, 'not_found', 'Projet introuvable.');
  if (input.length === 0) throw new AppError(400, 'empty', 'Fichier vide.');
  if (input.length > MAX_UPLOAD_BYTES) throw new AppError(413, 'too_large', 'Image trop lourde (10 Mo maximum).');

  const limit = { limitInputPixels: 50_000_000 };
  let meta: sharp.Metadata;
  try {
    meta = await sharp(input, limit).metadata();
  } catch {
    throw new AppError(415, 'bad_image', 'Ce fichier n’est pas une image lisible (PNG, JPEG, WebP, GIF ou AVIF).');
  }
  const ext = meta.format ? FORMATS[meta.format] : undefined;
  if (!ext || !meta.width || !meta.height) {
    throw new AppError(415, 'bad_image', 'Format non pris en charge. Utilisez PNG, JPEG, WebP, GIF ou AVIF (le SVG est refusé).');
  }

  const { base } = safeFilename(originalName);
  const id = uid(12);
  const stem = `${base}-${id.slice(0, 6)}`;
  const dir = mediaDir(projectId);
  fs.mkdirSync(dir, { recursive: true });

  const original = `orig-${stem}.${ext}`;
  const widths = [...new Set([...WIDTHS.filter((w) => w < meta.width!), Math.min(meta.width, WIDTHS[WIDTHS.length - 1])])].sort((a, b) => a - b);
  const written: string[] = [];
  try {
    fs.writeFileSync(path.join(dir, original), input);
    written.push(original);
    const variants: Variant[] = [];
    for (const w of widths) {
      const { data, info } = await sharp(input, limit)
        .rotate()
        .resize({ width: w, withoutEnlargement: true })
        .webp({ quality: 80 })
        .toBuffer({ resolveWithObject: true });
      const file = `${stem}-${w}.webp`;
      fs.writeFileSync(path.join(dir, file), data);
      written.push(file);
      variants.push({ w: info.width, h: info.height, file });
    }
    const row = { id, projectId, name: base, original, variants, createdAt: Date.now() };
    db.insert(assets).values(row).run();
    return toMeta(row);
  } catch (e) {
    for (const f of written) fs.rmSync(path.join(dir, f), { force: true });
    throw e instanceof AppError ? e : new AppError(500, 'image_failed', 'Le traitement de l’image a échoué.');
  }
}

export function deleteAsset(projectId: string, assetId: string): void {
  const db = getDb();
  const row = db.select().from(assets).where(and(eq(assets.id, assetId), eq(assets.projectId, projectId))).get();
  if (!row) throw new AppError(404, 'not_found', 'Média introuvable.');
  const project = db.select().from(projects).where(eq(projects.id, projectId)).get();
  if (project?.doc.sections.some((s) => s.type === 'header' && s.imageId === assetId)) {
    throw new AppError(409, 'in_use', 'Ce média est utilisé dans une section. Retirez-le d’abord.');
  }
  const dir = mediaDir(projectId);
  for (const f of [row.original, ...row.variants.map((v) => v.file)]) fs.rmSync(path.join(dir, f), { force: true });
  db.delete(assets).where(eq(assets.id, assetId)).run();
}

export function readMediaFile(projectId: string, file: string): { data: Buffer; type: string } {
  if (!FILE_RE.test(file) || file.includes('..')) throw new AppError(400, 'bad_file', 'Nom de fichier invalide.');
  const full = path.join(mediaDir(projectId), file);
  if (!fs.existsSync(full)) throw new AppError(404, 'not_found', 'Fichier introuvable.');
  const ext = file.split('.').pop() ?? '';
  return { data: fs.readFileSync(full), type: MIME[ext] ?? 'application/octet-stream' };
}

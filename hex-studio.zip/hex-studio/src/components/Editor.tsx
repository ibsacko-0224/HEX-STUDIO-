'use client';
import Link from 'next/link';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Site } from '../shared/render/Site';
import type { EditorBridge } from '../shared/render/ctx';
import { newSection } from '../shared/defaults';
import { moveItem, setIn, uid } from '../shared/lib';
import { SECTION_TYPES, type ProjectDoc, type Section, type SectionType } from '../shared/schema';
import { SECTION_META } from '../shared/tokens';
import type { AssetMeta } from '../shared/site';
import { api, jsonInit } from './api';
import { detectOverflow, type Overflow } from './overflow';
import { ChecksPanel, DesignPanel, MediaPanel, SectionPanel } from './Panels';
import { PublishDialog } from './PublishDialog';
import { Logo } from './Logo';

type Bp = 'desktop' | 'tablet' | 'mobile';
const BPS: Record<Bp, { w: number; label: string }> = {
  desktop: { w: 1280, label: 'Ordinateur' },
  tablet: { w: 820, label: 'Tablette' },
  mobile: { w: 390, label: 'Mobile' },
};
const BP_ORDER: Bp[] = ['desktop', 'tablet', 'mobile'];
type Tab = 'section' | 'design' | 'media' | 'checks';
type SaveState = { state: 'saved' | 'dirty' | 'saving' | 'error'; message?: string };
type ProjectData = { id: string; name: string; slug: string; doc: ProjectDoc; assets: AssetMeta[] };

const snippet = (s: Section) => {
  const v = s.type === 'footer' ? s.brand : s.title;
  return v.length > 34 ? `${v.slice(0, 34)}…` : v;
};

export function Editor({ id }: { id: string }) {
  const [phase, setPhase] = useState<'loading' | 'ready' | 'error'>('loading');
  const [loadError, setLoadError] = useState('');
  const [name, setName] = useState('');
  const [doc, setDoc] = useState<ProjectDoc | null>(null);
  const [assets, setAssets] = useState<AssetMeta[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('design');
  const [bp, setBp] = useState<Bp>('desktop');
  const [editing, setEditing] = useState(true);
  const [save, setSave] = useState<SaveState>({ state: 'saved' });
  const [issues, setIssues] = useState<Partial<Record<Bp, Overflow[]>>>({});
  const [auditing, setAuditing] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [viewW, setViewW] = useState(1000);
  const [, force] = useState(0);

  const docRef = useRef<ProjectDoc | null>(null);
  const nameRef = useRef('');
  const ver = useRef(0);
  const timer = useRef<number | undefined>(undefined);
  const hist = useRef<{ past: ProjectDoc[]; future: ProjectDoc[] }>({ past: [], future: [] });
  const frameRef = useRef<HTMLDivElement>(null);
  const viewRef = useRef<HTMLDivElement>(null);
  const scaleRef = useRef(1);

  // ───── chargement
  const load = useCallback(async () => {
    setPhase('loading');
    const r = await api<ProjectData>(`/api/projects/${id}`);
    if (!r.ok) { setLoadError(r.error); setPhase('error'); return; }
    docRef.current = r.data.doc; nameRef.current = r.data.name;
    setDoc(r.data.doc); setName(r.data.name); setAssets(r.data.assets);
    setSel(r.data.doc.sections[0]?.id ?? null);
    setPhase('ready');
  }, [id]);
  useEffect(() => { load(); }, [load]);

  // ───── enregistrement automatique (avec reprise si le serveur local est indisponible)
  const flush = useCallback(async (): Promise<boolean> => {
    window.clearTimeout(timer.current);
    const d = docRef.current;
    if (!d) return false;
    const v = ver.current;
    setSave({ state: 'saving' });
    const r = await api(`/api/projects/${id}`, jsonInit('PUT', { name: nameRef.current, doc: d }));
    if (!r.ok) {
      setSave({ state: 'error', message: r.error });
      if (r.offline) timer.current = window.setTimeout(() => { flush(); }, 5000);
      return false;
    }
    if (ver.current !== v) return flush();
    setSave({ state: 'saved' });
    return true;
  }, [id]);

  const markDirty = useCallback(() => {
    ver.current++;
    setSave({ state: 'dirty' });
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => { flush(); }, 700);
  }, [flush]);

  const ensureSaved = useCallback(async () => (save.state === 'saved' ? true : flush()), [save.state, flush]);

  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => { if (save.state === 'dirty' || save.state === 'error') e.preventDefault(); };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, [save.state]);

  // ───── édition + historique
  const setCurrent = useCallback((next: ProjectDoc) => { docRef.current = next; setDoc(next); markDirty(); }, [markDirty]);
  const apply = useCallback((next: ProjectDoc) => {
    const h = hist.current;
    h.past.push(docRef.current!);
    if (h.past.length > 50) h.past.shift();
    h.future = [];
    setCurrent(next);
  }, [setCurrent]);
  const undo = useCallback(() => {
    const h = hist.current; const prev = h.past.pop();
    if (!prev) return;
    h.future.push(docRef.current!); setCurrent(prev); force((n) => n + 1);
  }, [setCurrent]);
  const redo = useCallback(() => {
    const h = hist.current; const nxt = h.future.pop();
    if (!nxt) return;
    h.past.push(docRef.current!); setCurrent(nxt); force((n) => n + 1);
  }, [setCurrent]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [undo, redo]);

  const patch = useCallback((sid: string, fn: (s: Section) => Section) => {
    const d = docRef.current!;
    apply({ ...d, sections: d.sections.map((s) => (s.id === sid ? fn(s) : s)) });
  }, [apply]);

  const addSection = (type: SectionType) => {
    const d = docRef.current!;
    const s = newSection(type);
    const at = sel ? d.sections.findIndex((x) => x.id === sel) + 1 : d.sections.length;
    const sections = [...d.sections]; sections.splice(at, 0, s);
    apply({ ...d, sections }); setSel(s.id); setTab('section');
    setTimeout(() => frameRef.current?.querySelector(`[data-section="${s.id}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 60);
  };
  const removeSection = (sid: string) => {
    const d = docRef.current!;
    apply({ ...d, sections: d.sections.filter((s) => s.id !== sid) });
    if (sel === sid) setSel(null);
  };
  const duplicateSection = (sid: string) => {
    const d = docRef.current!; const i = d.sections.findIndex((s) => s.id === sid);
    const copy = { ...structuredClone(d.sections[i]), id: uid(10) } as Section;
    const sections = [...d.sections]; sections.splice(i + 1, 0, copy);
    apply({ ...d, sections }); setSel(copy.id);
  };
  const moveSection = (sid: string, dir: -1 | 1) => {
    const d = docRef.current!; const i = d.sections.findIndex((s) => s.id === sid);
    apply({ ...d, sections: moveItem(d.sections, i, i + dir) });
  };
  const jumpTo = (sid: string | null) => {
    if (!sid) return;
    setSel(sid); setTab('section');
    frameRef.current?.querySelector(`[data-section="${sid}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };
  const useInHeader = (assetId: string): string | null => {
    const d = docRef.current!;
    const target = d.sections.find((s) => s.id === sel && s.type === 'header') ?? d.sections.find((s) => s.type === 'header');
    if (!target) return 'Ajoutez d’abord une section « En-tête » pour y placer l’image.';
    patch(target.id, (s) => ({ ...s, imageId: assetId, imageAlt: (s as any).imageAlt || '' }) as Section);
    return null;
  };

  const bridge = useMemo<EditorBridge>(() => ({
    selectedId: sel,
    select: (sid) => { setSel(sid); setTab('section'); },
    commit: (sid, path, value) => patch(sid, (s) => setIn(s, path, value)),
  }), [sel, patch]);

  // ───── zone d'aperçu : échelle + contrôle des débordements
  useEffect(() => {
    const el = viewRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setViewW(el.clientWidth));
    ro.observe(el); setViewW(el.clientWidth);
    return () => ro.disconnect();
  }, [phase]);
  const scale = Math.min(1, Math.max(0.3, (viewW - 48) / BPS[bp].w));
  scaleRef.current = scale;

  useEffect(() => {
    if (phase !== 'ready') return;
    const t = window.setTimeout(() => {
      const f = frameRef.current;
      if (f) setIssues((p) => ({ ...p, [bp]: detectOverflow(f, scaleRef.current) }));
    }, 500);
    return () => window.clearTimeout(t);
  }, [doc, bp, phase, assets, editing]);

  const audit = async () => {
    setAuditing(true);
    const original = bp;
    const res: Record<Bp, Overflow[]> = { desktop: [], tablet: [], mobile: [] };
    for (const b of BP_ORDER) {
      setBp(b);
      await new Promise((r) => setTimeout(r, 300));
      if (frameRef.current) res[b] = detectOverflow(frameRef.current, scaleRef.current);
    }
    setIssues(res); setBp(original); setAuditing(false);
  };

  // ───── états de chargement / erreur
  if (phase === 'loading') {
    return (
      <div className="grid h-screen place-items-center bg-ed-bg" role="status">
        <div className="flex items-center gap-3 text-sm text-ed-ink"><span className="h-5 w-5 animate-spin rounded-full border-2 border-ed-line border-t-ed-accent" />Ouverture du projet…</div>
      </div>
    );
  }
  if (phase === 'error' || !doc) {
    return (
      <div className="grid h-screen place-items-center bg-ed-bg p-6">
        <div className="max-w-md rounded-2xl bg-white p-6 shadow-frame" role="alert">
          <h1 className="text-lg font-semibold text-ed-ink">Impossible d’ouvrir ce projet</h1>
          <p className="mt-2 text-sm text-ed-mute">{loadError}</p>
          <div className="mt-5 flex gap-2">
            <button onClick={load} className="rounded-lg bg-ed-accent px-4 py-2 text-sm font-semibold text-white">Réessayer</button>
            <Link href="/" className="rounded-lg px-4 py-2 text-sm font-medium text-ed-ink hover:bg-ed-bg">Retour aux projets</Link>
          </div>
        </div>
      </div>
    );
  }

  const selected = doc.sections.find((s) => s.id === sel) ?? null;
  const usedIds = new Set(doc.sections.flatMap((s) => (s.type === 'header' && s.imageId ? [s.imageId] : [])));
  const tabs: [Tab, string][] = [['section', 'Section'], ['design', 'Design'], ['media', 'Médias'], ['checks', 'Contrôles']];
  const badge = (b: Bp) => issues[b]?.length ?? 0;
  const saveLabel = { saved: 'Enregistré', dirty: 'Modifications en attente…', saving: 'Enregistrement…', error: 'Non enregistré' }[save.state];

  return (
    <div className="grid h-screen grid-rows-[auto_1fr] bg-ed-bg text-ed-ink">
      <header className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-ed-line bg-white px-4 py-2">
        <Link href="/" className="flex items-center gap-2" aria-label="Retour aux projets"><Logo /></Link>
        <input aria-label="Nom du projet" value={name} maxLength={80}
          onChange={(e) => { setName(e.target.value); nameRef.current = e.target.value || 'Sans titre'; markDirty(); }}
          className="w-48 rounded-md border border-transparent px-2 py-1 text-sm font-semibold hover:border-ed-line focus:border-ed-accent" />
        <span role="status" className={`text-xs ${save.state === 'error' ? 'font-medium text-red-600' : 'text-ed-mute'}`}>{saveLabel}</span>
        {save.state === 'error' && <button onClick={() => flush()} className="rounded-md border border-red-300 px-2 py-0.5 text-xs font-medium text-red-700">Réessayer</button>}

        <div className="mx-auto flex items-center gap-1 rounded-xl bg-ed-bg p-1" role="radiogroup" aria-label="Largeur d’aperçu">
          {BP_ORDER.map((b) => (
            <button key={b} role="radio" aria-checked={bp === b} onClick={() => setBp(b)}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium ${bp === b ? 'bg-white shadow-sm' : 'text-ed-mute hover:text-ed-ink'}`}>
              {BPS[b].label} <span className="font-mono text-[11px] opacity-60">{BPS[b].w}</span>
              {issues[b] && badge(b) > 0 && <span className="rounded-full bg-amber-500 px-1.5 text-[10px] font-bold text-white" title="Débordements détectés">{badge(b)}</span>}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1">
          <button onClick={undo} disabled={hist.current.past.length === 0} aria-label="Annuler" className="rounded-md px-2 py-1 text-sm hover:bg-ed-bg disabled:opacity-30">↶</button>
          <button onClick={redo} disabled={hist.current.future.length === 0} aria-label="Rétablir" className="rounded-md px-2 py-1 text-sm hover:bg-ed-bg disabled:opacity-30">↷</button>
          <button onClick={() => setEditing((v) => !v)} aria-pressed={!editing} className="rounded-md px-3 py-1.5 text-xs font-medium hover:bg-ed-bg">{editing ? 'Aperçu' : 'Modifier'}</button>
          <a href={`/api/projects/${id}/export`} download className="rounded-md px-3 py-1.5 text-xs font-medium hover:bg-ed-bg">Exporter JSON</a>
          <button onClick={() => setPublishOpen(true)} className="rounded-lg bg-ed-accent px-4 py-1.5 text-sm font-semibold text-white hover:opacity-90">Publier</button>
        </div>
      </header>

      <div className="grid min-h-0 grid-cols-[250px_minmax(0,1fr)_320px]">
        <aside className="flex min-h-0 flex-col border-r border-ed-line bg-white" aria-label="Sections">
          <h2 className="border-b border-ed-line px-4 py-3 text-sm font-semibold">Sections</h2>
          <ol className="min-h-0 flex-1 space-y-1 overflow-auto p-2">
            {doc.sections.length === 0 && <li className="p-4 text-center text-sm text-ed-mute">Page vide. Ajoutez une première section ci-dessous.</li>}
            {doc.sections.map((s, i) => (
              <li key={s.id} className={`group rounded-lg border ${sel === s.id ? 'border-ed-accent bg-violet-50' : 'border-transparent hover:bg-ed-bg'}`}>
                <button onClick={() => jumpTo(s.id)} className="block w-full px-3 pt-2 text-left">
                  <span className="block text-sm font-medium">{SECTION_META[s.type].label}</span>
                  <span className="block truncate text-xs text-ed-mute">{snippet(s) || '—'}</span>
                </button>
                <div className="flex gap-0.5 px-2 pb-1.5 pt-1 text-xs text-ed-mute">
                  <button aria-label="Monter" disabled={i === 0} onClick={() => moveSection(s.id, -1)} className="rounded px-1.5 hover:bg-white disabled:opacity-30">↑</button>
                  <button aria-label="Descendre" disabled={i === doc.sections.length - 1} onClick={() => moveSection(s.id, 1)} className="rounded px-1.5 hover:bg-white disabled:opacity-30">↓</button>
                  <button aria-label="Dupliquer" onClick={() => duplicateSection(s.id)} className="rounded px-1.5 hover:bg-white">Dupliquer</button>
                  <button aria-label="Supprimer" onClick={() => removeSection(s.id)} className="ml-auto rounded px-1.5 text-red-600 hover:bg-white">Supprimer</button>
                </div>
              </li>
            ))}
          </ol>
          <div className="border-t border-ed-line p-3">
            <h3 className="mb-2 text-xs font-medium text-ed-mute">Bibliothèque de sections</h3>
            <div className="grid grid-cols-2 gap-1.5">
              {SECTION_TYPES.map((t) => (
                <button key={t} onClick={() => addSection(t)} title={SECTION_META[t].hint}
                  className="rounded-lg border border-ed-line px-2 py-2 text-left text-xs font-medium hover:border-ed-accent hover:bg-violet-50">+ {SECTION_META[t].label}</button>
              ))}
            </div>
          </div>
        </aside>

        <main ref={viewRef} className="min-h-0 overflow-auto p-6" aria-label="Aperçu de la page">
          <p className="mb-3 text-center font-mono text-xs text-ed-mute">{BPS[bp].label} · {BPS[bp].w} px · zoom {Math.round(scale * 100)} %</p>
          <div ref={frameRef} className="mx-auto bg-white shadow-frame" style={{ width: BPS[bp].w, zoom: scale }}>
            {doc.sections.length === 0 ? (
              <div className="grid min-h-[320px] place-items-center p-10 text-center text-sm text-ed-mute">Cette page est vide.<br />Utilisez la bibliothèque à gauche pour ajouter une section.</div>
            ) : (
              <Site doc={doc} assets={assets} mediaBase={`/api/media/${id}`} editor={editing ? bridge : undefined} />
            )}
          </div>
        </main>

        <aside className="flex min-h-0 flex-col border-l border-ed-line bg-white" aria-label="Propriétés">
          <div className="flex border-b border-ed-line" role="tablist">
            {tabs.map(([k, l]) => (
              <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
                className={`flex-1 border-b-2 px-2 py-3 text-xs font-medium ${tab === k ? 'border-ed-accent text-ed-ink' : 'border-transparent text-ed-mute hover:text-ed-ink'}`}>{l}</button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-auto p-4" role="tabpanel">
            {tab === 'design' && <DesignPanel doc={doc} onChange={apply} />}
            {tab === 'section' && (selected
              ? <SectionPanel key={selected.id} section={selected} assets={assets} onPatch={(fn) => patch(selected.id, fn)} />
              : <p className="mt-8 text-center text-sm text-ed-mute">Sélectionnez une section dans la liste ou cliquez dessus dans l’aperçu.</p>)}
            {tab === 'media' && <MediaPanel projectId={id} assets={assets} usedIds={usedIds} onAssets={setAssets} onUseInHeader={useInHeader} />}
            {tab === 'checks' && <ChecksPanel issues={issues} auditing={auditing} onAudit={audit} onJump={jumpTo} />}
          </div>
        </aside>
      </div>

      {publishOpen && <PublishDialog id={id} ensureSaved={ensureSaved} onClose={() => setPublishOpen(false)} />}
    </div>
  );
}

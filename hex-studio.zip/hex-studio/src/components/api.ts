export type ApiResult<T> = { ok: true; data: T } | { ok: false; error: string; offline?: boolean };

/** fetch qui ne jette jamais : l'interface affiche toujours un état récupérable. */
export async function api<T = unknown>(url: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const res = await fetch(url, init);
    const body = await res.json().catch(() => null);
    if (!res.ok) return { ok: false, error: body?.error?.message ?? `Erreur serveur (${res.status}).` };
    return { ok: true, data: body as T };
  } catch {
    return {
      ok: false,
      offline: true,
      error: 'Le serveur local ne répond pas. Vérifiez que « node scripts/first-run.mjs » tourne toujours dans votre terminal.',
    };
  }
}

export const jsonInit = (method: string, body: unknown): RequestInit => ({
  method,
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(body),
});

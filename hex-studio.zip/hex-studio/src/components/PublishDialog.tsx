'use client';
import { useEffect, useState } from 'react';
import { formatBytes } from '../shared/lib';
import { api, jsonInit } from './api';

type Health = { deploy: { configured: boolean; target?: string; message?: string } };
type Result = { slug: string; outDir: string; files: number; bytes: number; durationMs: number; deploy: { ok: boolean; message: string } | null };
type State = { s: 'idle' } | { s: 'building' } | { s: 'ok'; r: Result } | { s: 'err'; msg: string };

export function PublishDialog({ id, ensureSaved, onClose }: { id: string; ensureSaved: () => Promise<boolean>; onClose: () => void }) {
  const [health, setHealth] = useState<Health | null>(null);
  const [deploy, setDeploy] = useState(false);
  const [state, setState] = useState<State>({ s: 'idle' });

  useEffect(() => {
    api<Health>('/api/health').then((r) => setHealth(r.ok ? r.data : null));
  }, []);
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === 'Escape' && state.s !== 'building' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [state.s, onClose]);

  async function run() {
    setState({ s: 'building' });
    if (!(await ensureSaved())) {
      setState({ s: 'err', msg: 'Le projet n’a pas pu être enregistré. Corrigez l’erreur d’enregistrement puis réessayez.' });
      return;
    }
    const r = await api<Result>(`/api/projects/${id}/publish`, jsonInit('POST', { deploy }));
    setState(r.ok ? { s: 'ok', r: r.data } : { s: 'err', msg: r.error });
  }

  const canDeploy = health?.deploy.configured === true;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-ed-ink/50 p-4" role="dialog" aria-modal="true" aria-labelledby="pub-title">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-frame">
        <h2 id="pub-title" className="text-xl font-semibold text-ed-ink">Publier le site</h2>

        {state.s === 'idle' && (
          <>
            <p className="mt-2 text-sm text-ed-mute">
              Construit un dossier statique dans <code className="rounded bg-ed-bg px-1">exports/</code>. L’opération prend généralement 20 à 60 secondes.
            </p>
            <label className={`mt-5 flex items-start gap-3 rounded-lg border border-ed-line p-3 text-sm ${canDeploy ? '' : 'opacity-60'}`}>
              <input type="checkbox" className="mt-0.5" disabled={!canDeploy} checked={deploy} onChange={(e) => setDeploy(e.target.checked)} />
              <span>
                <span className="font-medium text-ed-ink">Envoyer ensuite sur ma cible (rsync via SSH)</span>
                <span className="mt-0.5 block text-ed-mute">
                  {health === null ? 'Vérification de la configuration…' : canDeploy ? health.deploy.target : health.deploy.message}
                </span>
              </span>
            </label>
            <div className="mt-6 flex justify-end gap-2">
              <button onClick={onClose} className="rounded-lg px-4 py-2 text-sm font-medium text-ed-ink hover:bg-ed-bg">Annuler</button>
              <button onClick={run} className="rounded-lg bg-ed-accent px-4 py-2 text-sm font-semibold text-white hover:opacity-90">Construire{deploy ? ' et envoyer' : ''}</button>
            </div>
          </>
        )}

        {state.s === 'building' && (
          <div className="mt-6 flex items-center gap-3 text-sm text-ed-ink" role="status">
            <span className="h-5 w-5 animate-spin rounded-full border-2 border-ed-line border-t-ed-accent" />
            Construction en cours… ne fermez pas cette fenêtre.
          </div>
        )}

        {state.s === 'ok' && (
          <div className="mt-4 text-sm" role="status">
            <p className="font-medium text-emerald-700">Site construit en {(state.r.durationMs / 1000).toFixed(1)} s.</p>
            <dl className="mt-3 space-y-1 text-ed-ink">
              <div><dt className="inline text-ed-mute">Dossier : </dt><dd className="inline break-all font-mono text-xs">{state.r.outDir}</dd></div>
              <div><dt className="inline text-ed-mute">Contenu : </dt><dd className="inline">{state.r.files} fichiers, {formatBytes(state.r.bytes)}</dd></div>
            </dl>
            {state.r.deploy && (
              <p className={`mt-3 rounded-lg p-3 ${state.r.deploy.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-900'}`}>
                {state.r.deploy.ok ? 'Publié. ' : 'Le site est construit, mais l’envoi a échoué. '}{state.r.deploy.message}
              </p>
            )}
            <div className="mt-6 flex justify-end gap-2">
              {state.r.deploy && !state.r.deploy.ok && <button onClick={run} className="rounded-lg border border-ed-line px-4 py-2 text-sm font-medium">Réessayer l’envoi</button>}
              <button onClick={onClose} className="rounded-lg bg-ed-ink px-4 py-2 text-sm font-semibold text-white">Fermer</button>
            </div>
          </div>
        )}

        {state.s === 'err' && (
          <div className="mt-4 text-sm" role="alert">
            <p className="font-medium text-red-700">La publication a échoué.</p>
            <pre className="mt-2 max-h-48 overflow-auto whitespace-pre-wrap rounded-lg bg-ed-bg p-3 text-xs text-ed-ink">{state.msg}</pre>
            <p className="mt-2 text-ed-mute">Votre projet est intact. Corrigez le problème puis relancez.</p>
            <div className="mt-6 flex justify-end gap-2">
              <button onClick={onClose} className="rounded-lg px-4 py-2 text-sm font-medium hover:bg-ed-bg">Fermer</button>
              <button onClick={run} className="rounded-lg bg-ed-accent px-4 py-2 text-sm font-semibold text-white">Réessayer</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

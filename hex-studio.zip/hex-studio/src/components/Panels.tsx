'use client';
import { useRef, useState, type ReactNode } from 'react';
import { FONTS, ICONS, MODES, PALETTES, RADII, SPACINGS, type ProjectDoc, type Section } from '../shared/schema';
import { PALETTE_SWATCH, SECTION_META } from '../shared/tokens';
import { isSafeHref, moveItem } from '../shared/lib';
import type { AssetMeta } from '../shared/site';
import { api } from './api';
import type { Overflow } from './overflow';

type Bp = 'desktop' | 'tablet' | 'mobile';
const BP_LABEL: Record<Bp, string> = { desktop: 'Ordinateur', tablet: 'Tablette', mobile: 'Mobile' };

// ───────── petits composants de formulaire
function Seg<T extends string>({ label, value, options, onChange }: {
  label: string; value: T; options: readonly { v: T; l: string }[]; onChange: (v: T) => void;
}) {
  return (
    <fieldset className="mb-4">
      <legend className="mb-1.5 text-xs font-medium text-ed-mute">{label}</legend>
      <div className="flex rounded-lg border border-ed-line bg-ed-bg p-0.5" role="radiogroup" aria-label={label}>
        {options.map((o) => (
          <button key={o.v} type="button" role="radio" aria-checked={o.v === value} onClick={() => onChange(o.v)}
            className={`flex-1 rounded-md px-2 py-1.5 text-xs font-medium ${o.v === value ? 'bg-white text-ed-ink shadow-sm' : 'text-ed-mute hover:text-ed-ink'}`}>
            {o.l}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function Field({ label, value, onCommit, url, multiline, max = 200 }: {
  label: string; value: string; onCommit: (v: string) => void; url?: boolean; multiline?: boolean; max?: number;
}) {
  const [v, setV] = useState(value);
  const [last, setLast] = useState(value);
  if (value !== last) { setLast(value); setV(value); }
  const bad = url && !isSafeHref(v);
  const cls = `w-full rounded-lg border px-2.5 py-1.5 text-sm text-ed-ink ${bad ? 'border-red-500' : 'border-ed-line'}`;
  const commit = () => { if (!bad && v !== value) onCommit(v); };
  return (
    <label className="mb-3 block">
      <span className="mb-1 block text-xs font-medium text-ed-mute">{label}</span>
      {multiline
        ? <textarea className={cls} rows={3} maxLength={max} value={v} onChange={(e) => setV(e.target.value)} onBlur={commit} />
        : <input className={cls} maxLength={max} value={v} onChange={(e) => setV(e.target.value)} onBlur={commit} inputMode={url ? 'url' : undefined} />}
      {bad && <span className="mt-1 block text-xs text-red-600">Lien invalide : utilisez https://…, mailto:…, tel:…, #ancre ou /chemin.</span>}
    </label>
  );
}

const Group = ({ title, children }: { title: string; children: ReactNode }) => (
  <section className="mb-6"><h3 className="mb-2 text-sm font-semibold text-ed-ink">{title}</h3>{children}</section>
);

// ───────── Design : jetons contraints
export function DesignPanel({ doc, onChange }: { doc: ProjectDoc; onChange: (d: ProjectDoc) => void }) {
  const set = (p: Partial<ProjectDoc['theme']>) => onChange({ ...doc, theme: { ...doc.theme, ...p } });
  const t = doc.theme;
  return (
    <div>
      <Group title="Thème">
        <fieldset className="mb-4">
          <legend className="mb-1.5 text-xs font-medium text-ed-mute">Couleur de marque</legend>
          <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Couleur de marque">
            {PALETTES.map((p) => (
              <button key={p} type="button" role="radio" aria-checked={t.palette === p} aria-label={PALETTE_SWATCH[p].label} title={PALETTE_SWATCH[p].label}
                onClick={() => set({ palette: p })}
                className={`h-8 w-8 rounded-full border-2 ${t.palette === p ? 'border-ed-ink ring-2 ring-white ring-offset-1 ring-offset-ed-ink' : 'border-white'}`}
                style={{ background: PALETTE_SWATCH[p].hex }} />
            ))}
          </div>
        </fieldset>
        <Seg label="Mode" value={t.mode} onChange={(v) => set({ mode: v })} options={MODES.map((v) => ({ v, l: v === 'light' ? 'Clair' : 'Sombre' }))} />
        <Seg label="Typographie" value={t.font} onChange={(v) => set({ font: v })} options={FONTS.map((v) => ({ v, l: { sans: 'Sans', editorial: 'Éditoriale', mono: 'Mono' }[v] }))} />
        <Seg label="Arrondis" value={t.radius} onChange={(v) => set({ radius: v })} options={RADII.map((v) => ({ v, l: { none: 'Aucun', md: 'Moyen', xl: 'Grand' }[v] }))} />
        <Seg label="Espacement" value={t.spacing} onChange={(v) => set({ spacing: v })} options={SPACINGS.map((v) => ({ v, l: { compact: 'Serré', cozy: 'Normal', airy: 'Aéré' }[v] }))} />
      </Group>
      <Group title="Référencement">
        <Field label="Titre de la page" value={doc.seo.title} max={120} onCommit={(v) => onChange({ ...doc, seo: { ...doc.seo, title: v } })} />
        <Field label="Description" value={doc.seo.description} multiline max={300} onCommit={(v) => onChange({ ...doc, seo: { ...doc.seo, description: v } })} />
        <Field label="Langue (ex. fr, en)" value={doc.lang} max={8} onCommit={(v) => /^[a-z]{2}(-[A-Za-z]{2})?$/.test(v) && onChange({ ...doc, lang: v })} />
      </Group>
    </div>
  );
}

// ───────── Section sélectionnée
type ArrayCfg = { key: string; label: string; make: () => unknown; title: (it: any) => string };
const ARRAYS: Record<string, ArrayCfg[]> = {
  proof: [
    { key: 'stats', label: 'Chiffres', make: () => ({ value: '0', label: 'Nouveau chiffre' }), title: (i) => `${i.value} ${i.label}` },
    { key: 'quotes', label: 'Témoignages', make: () => ({ quote: 'Votre témoignage.', author: 'Prénom Nom', role: 'Rôle' }), title: (i) => i.author },
  ],
  features: [{ key: 'items', label: 'Fonctionnalités', make: () => ({ icon: 'bolt', title: 'Nouvelle fonctionnalité', text: 'Décrivez le bénéfice en une phrase.' }), title: (i) => i.title }],
  pricing: [{ key: 'plans', label: 'Formules', make: () => ({ name: 'Nouvelle formule', price: '0 €', period: 'par mois', description: 'Description courte.', features: ['Un avantage'], ctaLabel: 'Choisir', ctaHref: '#', highlighted: false }), title: (i) => i.name }],
  faq: [{ key: 'items', label: 'Questions', make: () => ({ q: 'Nouvelle question ?', a: 'Votre réponse.' }), title: (i) => i.q }],
  footer: [{ key: 'links', label: 'Liens', make: () => ({ label: 'Nouveau lien', href: '#' }), title: (i) => i.label }],
};
const LIMITS: Record<string, number> = { stats: 8, quotes: 9, items: 20, plans: 4, links: 12 };

export function SectionPanel({ section, assets, onPatch }: {
  section: Section; assets: AssetMeta[]; onPatch: (fn: (s: Section) => Section) => void;
}) {
  const s: any = section;
  const patch = (p: Record<string, unknown>) => onPatch((x) => ({ ...x, ...p }) as Section);
  const setArr = (key: string, next: unknown[]) => patch({ [key]: next });
  const setItem = (key: string, i: number, p: Record<string, unknown>) => setArr(key, s[key].map((it: any, j: number) => (j === i ? { ...it, ...p } : it)));

  return (
    <div>
      <h2 className="mb-4 text-base font-semibold text-ed-ink">{SECTION_META[section.type].label}</h2>
      <Group title="Style">
        <Seg label="Alignement" value={section.style.align} onChange={(v) => patch({ style: { ...section.style, align: v } })} options={[{ v: 'left', l: 'Gauche' }, { v: 'center', l: 'Centré' }]} />
        <Seg label="Fond" value={section.style.background} onChange={(v) => patch({ style: { ...section.style, background: v } })} options={[{ v: 'plain', l: 'Uni' }, { v: 'tint', l: 'Teinté' }, { v: 'brand', l: 'Marque' }]} />
      </Group>

      {section.type === 'header' && (
        <Group title="Liens et image">
          <Field label="Lien du bouton principal" url value={section.ctaHref} max={500} onCommit={(v) => patch({ ctaHref: v })} />
          <Field label="Lien du bouton secondaire" url value={section.secondaryHref} max={500} onCommit={(v) => patch({ secondaryHref: v })} />
          <label className="mb-3 block">
            <span className="mb-1 block text-xs font-medium text-ed-mute">Image</span>
            <select className="w-full rounded-lg border border-ed-line px-2.5 py-1.5 text-sm" value={section.imageId ?? ''} onChange={(e) => patch({ imageId: e.target.value || null })}>
              <option value="">Aucune image</option>
              {assets.map((a) => <option key={a.id} value={a.id}>{a.name} ({a.width}×{a.height})</option>)}
            </select>
            {assets.length === 0 && <span className="mt-1 block text-xs text-ed-mute">Importez d’abord une image dans l’onglet Médias.</span>}
          </label>
          {section.imageId && <Field label="Texte alternatif (accessibilité)" value={section.imageAlt} max={200} onCommit={(v) => patch({ imageAlt: v })} />}
        </Group>
      )}

      {(ARRAYS[section.type] ?? []).map((cfg) => (
        <Group key={cfg.key} title={cfg.label}>
          <ul className="space-y-2">
            {(s[cfg.key] as any[]).map((it, i, arr) => (
              <li key={i} className="rounded-lg border border-ed-line p-2.5">
                <div className="flex items-center gap-1">
                  <span className="min-w-0 flex-1 truncate text-sm font-medium text-ed-ink">{cfg.title(it) || '(vide)'}</span>
                  <button aria-label="Monter" disabled={i === 0} onClick={() => setArr(cfg.key, moveItem(arr, i, i - 1))} className="rounded px-1.5 py-0.5 text-ed-mute hover:bg-ed-bg disabled:opacity-30">↑</button>
                  <button aria-label="Descendre" disabled={i === arr.length - 1} onClick={() => setArr(cfg.key, moveItem(arr, i, i + 1))} className="rounded px-1.5 py-0.5 text-ed-mute hover:bg-ed-bg disabled:opacity-30">↓</button>
                  <button aria-label="Supprimer" onClick={() => setArr(cfg.key, arr.filter((_, j) => j !== i))} className="rounded px-1.5 py-0.5 text-red-600 hover:bg-red-50">✕</button>
                </div>
                {'icon' in it && (
                  <select aria-label="Icône" className="mt-2 w-full rounded-lg border border-ed-line px-2 py-1 text-sm" value={it.icon} onChange={(e) => setItem(cfg.key, i, { icon: e.target.value })}>
                    {ICONS.map((ic) => <option key={ic} value={ic}>{{ bolt: 'Éclair', shield: 'Bouclier', chart: 'Graphique', globe: 'Globe', heart: 'Cœur', layers: 'Couches' }[ic]}</option>)}
                  </select>
                )}
                {'href' in it && <div className="mt-2"><Field label="Lien" url value={it.href} max={500} onCommit={(v) => setItem(cfg.key, i, { href: v })} /></div>}
                {'ctaHref' in it && <div className="mt-2"><Field label="Lien du bouton" url value={it.ctaHref} max={500} onCommit={(v) => setItem(cfg.key, i, { ctaHref: v })} /></div>}
                {'highlighted' in it && (
                  <>
                    <label className="mt-1 flex items-center gap-2 text-sm"><input type="checkbox" checked={it.highlighted} onChange={(e) => setItem(cfg.key, i, { highlighted: e.target.checked })} /> Formule mise en avant</label>
                    <div className="mt-2">
                      <Field label="Avantages (un par ligne)" multiline max={1500} value={(it.features as string[]).join('\n')}
                        onCommit={(v) => setItem(cfg.key, i, { features: v.split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 12) })} />
                    </div>
                  </>
                )}
              </li>
            ))}
          </ul>
          <button disabled={s[cfg.key].length >= LIMITS[cfg.key]} onClick={() => setArr(cfg.key, [...s[cfg.key], cfg.make()])}
            className="mt-2 w-full rounded-lg border border-dashed border-ed-line px-3 py-2 text-sm font-medium text-ed-accent hover:bg-ed-bg disabled:opacity-40">
            + Ajouter
          </button>
        </Group>
      ))}
      <p className="text-xs text-ed-mute">Astuce : cliquez directement sur un texte dans l’aperçu pour le modifier. Entrée valide, Échap quitte.</p>
    </div>
  );
}

// ───────── Médias
export function MediaPanel({ projectId, assets, usedIds, onAssets, onUseInHeader }: {
  projectId: string; assets: AssetMeta[]; usedIds: Set<string>;
  onAssets: (a: AssetMeta[]) => void; onUseInHeader: (id: string) => string | null;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const input = useRef<HTMLInputElement>(null);

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr(null); setOk(null);
    const added: AssetMeta[] = [];
    const errors: string[] = [];
    for (const f of Array.from(files)) {
      if (!f.type.startsWith('image/')) { errors.push(`${f.name} : ce n’est pas une image.`); continue; }
      if (f.size > 10 * 1024 * 1024) { errors.push(`${f.name} : plus de 10 Mo.`); continue; }
      const fd = new FormData();
      fd.append('file', f);
      const r = await api<AssetMeta>(`/api/projects/${projectId}/media`, { method: 'POST', body: fd });
      if (r.ok) added.push(r.data); else errors.push(`${f.name} : ${r.error}`);
    }
    if (added.length) { onAssets([...assets, ...added]); setOk(`${added.length} image(s) importée(s) et optimisée(s).`); }
    if (errors.length) setErr(errors.join(' '));
    setBusy(false);
    if (input.current) input.current.value = '';
  }

  async function remove(a: AssetMeta) {
    if (!confirm(`Supprimer « ${a.name} » ?`)) return;
    setErr(null); setOk(null);
    const r = await api(`/api/projects/${projectId}/media/${a.id}`, { method: 'DELETE' });
    if (r.ok) onAssets(assets.filter((x) => x.id !== a.id)); else setErr(r.error);
  }

  return (
    <div>
      <h2 className="mb-1 text-base font-semibold text-ed-ink">Médias</h2>
      <p className="mb-4 text-xs text-ed-mute">PNG, JPEG, WebP, GIF ou AVIF, 10 Mo max. Trois tailles responsives sont générées en WebP.</p>
      <input ref={input} type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/avif" multiple className="sr-only" id="upload" onChange={(e) => upload(e.target.files)} />
      <label htmlFor="upload" className={`block cursor-pointer rounded-xl border-2 border-dashed border-ed-line p-5 text-center text-sm font-medium text-ed-accent hover:bg-ed-bg ${busy ? 'pointer-events-none opacity-60' : ''}`}>
        {busy ? 'Optimisation en cours…' : 'Choisir des images'}
      </label>
      {err && <p role="alert" className="mt-3 rounded-lg bg-red-50 p-2.5 text-xs text-red-700">{err}</p>}
      {ok && <p role="status" className="mt-3 rounded-lg bg-emerald-50 p-2.5 text-xs text-emerald-800">{ok}</p>}
      {assets.length === 0 ? (
        <p className="mt-6 text-center text-sm text-ed-mute">Aucune image pour l’instant.</p>
      ) : (
        <ul className="mt-5 space-y-3">
          {assets.map((a) => (
            <li key={a.id} className="flex gap-3 rounded-lg border border-ed-line p-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={`/api/media/${projectId}/${[...a.variants].sort((x, y) => x.w - y.w)[0].file}`} alt="" className="h-16 w-16 shrink-0 rounded object-cover" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-ed-ink">{a.name}</p>
                <p className="text-xs text-ed-mute">{a.width}×{a.height} · {a.variants.length} tailles{usedIds.has(a.id) ? ' · utilisée' : ''}</p>
                <div className="mt-1 flex gap-3 text-xs font-medium">
                  <button className="text-ed-accent" onClick={() => { const e = onUseInHeader(a.id); setErr(e); }}>Utiliser en en-tête</button>
                  <button className="text-red-600" onClick={() => remove(a)}>Supprimer</button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ───────── Contrôles de débordement
export function ChecksPanel({ issues, auditing, onAudit, onJump }: {
  issues: Partial<Record<Bp, Overflow[]>>; auditing: boolean; onAudit: () => void; onJump: (id: string | null) => void;
}) {
  const order: Bp[] = ['desktop', 'tablet', 'mobile'];
  const audited = order.every((b) => issues[b]);
  const total = order.reduce((n, b) => n + (issues[b]?.length ?? 0), 0);
  return (
    <div>
      <h2 className="mb-1 text-base font-semibold text-ed-ink">Contrôles</h2>
      <p className="mb-4 text-xs text-ed-mute">Détecte les éléments qui dépassent du cadre sur ordinateur (1280 px), tablette (820 px) et mobile (390 px).</p>
      <button onClick={onAudit} disabled={auditing} className="mb-4 w-full rounded-lg bg-ed-ink px-3 py-2 text-sm font-semibold text-white disabled:opacity-60">
        {auditing ? 'Analyse en cours…' : 'Vérifier les trois largeurs'}
      </button>
      {audited && total === 0 && <p role="status" className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">Aucun débordement détecté sur les trois largeurs.</p>}
      {order.map((b) => (
        <section key={b} className="mb-4">
          <h3 className="mb-1.5 flex items-center justify-between text-sm font-semibold text-ed-ink">
            {BP_LABEL[b]}
            <span className={`rounded-full px-2 py-0.5 text-xs ${!issues[b] ? 'bg-ed-bg text-ed-mute' : issues[b]!.length ? 'bg-amber-100 text-amber-900' : 'bg-emerald-100 text-emerald-800'}`}>
              {!issues[b] ? 'non vérifié' : issues[b]!.length ? `${issues[b]!.length} problème(s)` : 'OK'}
            </span>
          </h3>
          <ul className="space-y-1.5">
            {(issues[b] ?? []).map((o, i) => (
              <li key={i}>
                <button onClick={() => onJump(o.sectionId)} className="w-full rounded-lg border border-amber-200 bg-amber-50 p-2 text-left text-xs text-amber-900 hover:bg-amber-100">
                  {o.label}<br /><span className="opacity-80">dépasse de {o.excess} px · cliquer pour afficher la section</span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

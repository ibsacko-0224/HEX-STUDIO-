export type Overflow = { sectionId: string | null; label: string; excess: number };

function describe(el: Element): string {
  const tag = el.tagName.toLowerCase();
  const text = (el.textContent ?? '').trim().replace(/\s+/g, ' ').slice(0, 28);
  return text ? `<${tag}> « ${text}${text.length >= 28 ? '…' : ''} »` : `<${tag}>`;
}

/**
 * Cherche les éléments qui dépassent à droite du cadre de prévisualisation.
 * `scale` : facteur de zoom du cadre (les mesures du navigateur sont en pixels écran).
 */
export function detectOverflow(frame: HTMLElement, scale = 1): Overflow[] {
  const limit = frame.getBoundingClientRect().right;
  const flagged = new Set<Element>();
  const out: Overflow[] = [];
  frame.querySelectorAll('main *').forEach((el) => {
    const r = el.getBoundingClientRect();
    if (r.width === 0 && r.height === 0) return;
    const excess = r.right - limit;
    if (excess <= 1) return;
    if (el.parentElement && flagged.has(el.parentElement)) return; // on ne signale que l'élément le plus haut
    flagged.add(el);
    out.push({
      sectionId: el.closest('[data-section]')?.getAttribute('data-section') ?? null,
      label: describe(el),
      excess: Math.round(excess / scale),
    });
  });
  return out.slice(0, 25);
}

import { createProject, listProjects } from '../../../server/projects';
import { handle, json, readJson } from '../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handle(async () => json(listProjects()));

export const POST = handle(async (req: Request) => {
  const body = (await readJson(req)) as { name?: unknown };
  return json(createProject(body.name), 201);
});

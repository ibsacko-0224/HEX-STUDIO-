import { importProject } from '../../../../server/projects';
import { handle, json, readJson } from '../../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = handle(async (req: Request) => json(await importProject(await readJson(req, 80_000_000)), 201));

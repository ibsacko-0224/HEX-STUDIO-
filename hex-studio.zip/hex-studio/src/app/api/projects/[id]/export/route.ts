import { exportProject, requireProject } from '../../../../../server/projects';
import { handle } from '../../../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handle(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const slug = requireProject(id).slug;
  return new Response(JSON.stringify(exportProject(id)), {
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'content-disposition': `attachment; filename="${slug}.hex-site.json"`,
      'cache-control': 'no-store',
    },
  });
});

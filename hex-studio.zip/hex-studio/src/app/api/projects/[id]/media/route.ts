import { addAsset, MAX_UPLOAD_BYTES } from '../../../../../server/media';
import { assertId } from '../../../../../server/projects';
import { AppError, handle, json } from '../../../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = handle(async (req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  assertId(id);
  if (Number(req.headers.get('content-length') ?? 0) > MAX_UPLOAD_BYTES + 1_000_000) {
    throw new AppError(413, 'too_large', 'Image trop lourde (10 Mo maximum).');
  }
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    throw new AppError(400, 'bad_form', 'Envoi invalide : un fichier image est attendu.');
  }
  const file = form.get('file');
  if (!(file instanceof File)) throw new AppError(400, 'no_file', 'Aucun fichier reçu.');
  return json(await addAsset(id, Buffer.from(await file.arrayBuffer()), file.name), 201);
});

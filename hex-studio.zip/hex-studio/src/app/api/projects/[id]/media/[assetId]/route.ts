import { deleteAsset } from '../../../../../../server/media';
import { assertId } from '../../../../../../server/projects';
import { handle, json } from '../../../../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const DELETE = handle(async (_req: Request, { params }: { params: Promise<{ id: string; assetId: string }> }) => {
  const { id, assetId } = await params;
  assertId(id);
  assertId(assetId);
  deleteAsset(id, assetId);
  return json({ ok: true });
});

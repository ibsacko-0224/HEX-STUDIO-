import { publishProject } from '../../../../../server/publish';
import { handle, json, readJson } from '../../../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = handle(async (req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const { id } = await params;
  const body = (await readJson(req)) as { deploy?: unknown };
  return json(await publishProject(id, { deploy: body.deploy === true }));
});

import { deleteProject, requireProject, saveProject } from '../../../../server/projects';
import { handle, json, readJson } from '../../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
type Ctx = { params: Promise<{ id: string }> };

export const GET = handle(async (_req: Request, { params }: Ctx) => json(requireProject((await params).id)));

export const PUT = handle(async (req: Request, { params }: Ctx) => {
  const body = (await readJson(req)) as { name?: unknown; doc?: unknown };
  return json(saveProject((await params).id, { name: body.name, doc: body.doc }));
});

export const DELETE = handle(async (_req: Request, { params }: Ctx) => {
  deleteProject((await params).id);
  return json({ ok: true });
});

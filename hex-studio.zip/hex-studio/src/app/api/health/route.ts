import { readDeployConfig } from '../../../server/publish';
import { handle, json } from '../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handle(async () => {
  const d = readDeployConfig();
  return json({
    ok: true,
    deploy: d.ok
      ? { configured: true, target: `${d.config.user}@${d.config.host}:${d.config.remotePath}` }
      : { configured: false, message: d.reason },
  });
});

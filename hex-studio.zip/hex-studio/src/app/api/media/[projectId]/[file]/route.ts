import { readMediaFile } from '../../../../../server/media';
import { assertId } from '../../../../../server/projects';
import { handle } from '../../../../../server/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handle(async (_req: Request, { params }: { params: Promise<{ projectId: string; file: string }> }) => {
  const { projectId, file } = await params;
  assertId(projectId);
  const { data, type } = readMediaFile(projectId, file);
  return new Response(new Uint8Array(data), {
    headers: { 'content-type': type, 'cache-control': 'private, max-age=31536000, immutable', 'x-content-type-options': 'nosniff' },
  });
});

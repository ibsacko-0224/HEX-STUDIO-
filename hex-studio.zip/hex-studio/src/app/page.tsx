'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useRef, useState } from 'react';
import { api, jsonInit } from '../components/api';
import { Logo } from '../components/Logo';

type Row = { id: string; name: string; slug: string; updatedAt: number; sections: number };
type Notice = { kind: 'ok' | 'err'; text: string } | null;

export default function Home() {
  const router = useRouter();
  const [rows, setRows] = useState<Row[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<Notice>(null);
  const file = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setError(null);
    const r = await api<Row[]>('/api/projects');
    if (r.ok) setRows(r.data); else { setRows(null); setError(r.error); }
  }, []);
  useEffect(() => { load(); }, [load]);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setNotice(null);
    const r = await api<{ id: string }>('/api/projects', jsonInit('POST', { name: name.trim() || 'Ma page d’accueil' }));
    setBusy(false);
    if (r.ok) router.push(`/editor/${r.data.id}`); else setNotice({ kind: 'err', text: r.error });
  }

  async function importFile(f: File | undefined) {
    if (!f) return;
    setBusy(true); setNotice(null);
    let payload: unknown;
    try { payload = JSON.parse(await f.text()); } catch { setBusy(false); setNotice({ kind: 'err', text: 'Ce fichier n’est pas un JSON valide.' }); return; }
    const r = await api<{ id: string; name: string }>('/api/projects/import', jsonInit('POST', payload));
    setBusy(false);
    if (file.current) file.current.value = '';
    if (r.ok) { setNotice({ kind: 'ok', text: `Projet « ${r.data.name} » importé.` }); load(); }
    else setNotice({ kind: 'err', text: `Import impossible : ${r.error}` });
  }

  async function remove(p: Row) {
    if (!confirm(`Supprimer définitivement « ${p.name} » et ses images ? Pensez à exporter une sauvegarde JSON avant.`)) return;
    const r = await api(`/api/projects/${p.id}`, { method: 'DELETE' });
    if (r.ok) { setNotice({ kind: 'ok', text: 'Projet supprimé.' }); load(); } else setNotice({ kind: 'err', text: r.error });
  }

  return (
    <main className="mx-auto grid min-h-screen max-w-5xl gap-12 px-6 py-12 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
      <section>
        <div className="mb-10 flex items-center gap-3"><Logo className="h-9 w-9" /><span className="text-lg font-semibold">Hex Studio</span></div>
        <h1 className="text-4xl font-semibold leading-tight tracking-tight text-balance">Votre page d’accueil, assemblée et publiée chez vous.</h1>
        <p className="mt-4 max-w-md text-ed-mute">Des blocs, du texte modifiable sur place, trois largeurs d’aperçu, un export statique. Vos données ne quittent pas cette machine.</p>
        <form onSubmit={create} className="mt-8 flex max-w-md gap-2">
          <label className="sr-only" htmlFor="pname">Nom du projet</label>
          <input id="pname" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} placeholder="Nom du projet"
            className="min-w-0 flex-1 rounded-lg border border-ed-line bg-white px-3 py-2.5 text-sm" />
          <button disabled={busy} className="rounded-lg bg-ed-accent px-5 py-2.5 text-sm font-semibold text-white hover:opacity-90 disabled:opacity-60">Créer</button>
        </form>
        <input ref={file} type="file" accept="application/json,.json" className="sr-only" id="imp" onChange={(e) => importFile(e.target.files?.[0])} />
        <label htmlFor="imp" className="mt-3 inline-block text-sm font-medium text-ed-accent underline-offset-4 hover:underline">Importer un export JSON</label>
        {notice && <p role={notice.kind === 'err' ? 'alert' : 'status'} className={`mt-5 max-w-md rounded-lg p-3 text-sm ${notice.kind === 'err' ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-800'}`}>{notice.text}</p>}
      </section>

      <section aria-label="Projets">
        <h2 className="mb-4 text-sm font-semibold text-ed-mute">Vos projets</h2>
        {rows === null && !error && <div role="status" className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-white" />)}</div>}
        {error && (
          <div role="alert" className="rounded-xl border border-red-200 bg-white p-5">
            <p className="font-medium text-red-700">Impossible de charger les projets.</p>
            <p className="mt-1 text-sm text-ed-mute">{error}</p>
            <button onClick={load} className="mt-4 rounded-lg bg-ed-ink px-4 py-2 text-sm font-semibold text-white">Réessayer</button>
          </div>
        )}
        {rows?.length === 0 && (
          <div className="rounded-xl border-2 border-dashed border-ed-line p-10 text-center">
            <p className="font-medium">Aucun projet pour l’instant.</p>
            <p className="mt-1 text-sm text-ed-mute">Donnez un nom à gauche et cliquez sur Créer : un modèle complet avec les six sections vous attend.</p>
          </div>
        )}
        {rows && rows.length > 0 && (
          <ul className="divide-y divide-ed-line overflow-hidden rounded-xl border border-ed-line bg-white">
            {rows.map((p) => (
              <li key={p.id} className="flex items-center gap-4 px-5 py-4">
                <div className="min-w-0 flex-1">
                  <Link href={`/editor/${p.id}`} className="block truncate font-semibold hover:text-ed-accent">{p.name}</Link>
                  <p className="text-xs text-ed-mute">{p.sections} sections · modifié le {new Date(p.updatedAt).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' })}</p>
                </div>
                <a href={`/api/projects/${p.id}/export`} download className="text-sm font-medium text-ed-mute hover:text-ed-ink">Exporter</a>
                <button onClick={() => remove(p)} className="text-sm font-medium text-red-600 hover:underline">Supprimer</button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}

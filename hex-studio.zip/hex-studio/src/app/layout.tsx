import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import '../shared/tokens.css';
import './globals.css';

export const metadata: Metadata = {
  title: 'Hex Studio',
  description: 'Créez, prévisualisez et publiez une page d’accueil statique, en local.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className="bg-ed-bg text-ed-ink antialiased">{children}</body>
    </html>
  );
}

// Préset partagé : l'éditeur et le site exporté utilisent exactement les mêmes jetons.
const c = (v) => `rgb(var(--${v}) / <alpha-value>)`;
module.exports = {
  theme: {
    extend: {
      colors: {
        bg: c('bg'), fg: c('fg'), muted: c('muted'), tint: c('tint'),
        border: c('border'), brand: c('brand'), 'brand-fg': c('brand-fg'),
      },
      fontFamily: { body: ['var(--font-body)'], head: ['var(--font-head)'] },
      borderRadius: { token: 'var(--radius)' },
    },
  },
  plugins: [require('@tailwindcss/container-queries')],
};

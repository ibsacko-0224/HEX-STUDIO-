#!/usr/bin/env node
// Première exécution en UNE commande :  node scripts/first-run.mjs
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';

const major = Number(process.versions.node.split('.')[0]);
if (major < 20) {
  console.error(`✗ Node 20.9+ requis (version détectée : ${process.versions.node}).`);
  process.exit(1);
}

if (!existsSync('.env')) {
  copyFileSync('.env.example', '.env');
  console.log('→ .env créé à partir de .env.example (rien n’est envoyé nulle part).');
}
mkdirSync('data', { recursive: true });

const win = process.platform === 'win32';
const npm = win ? 'npm.cmd' : 'npm';

if (!existsSync('node_modules')) {
  console.log('→ Installation des dépendances…');
  const r = spawnSync(npm, ['install', '--no-audit', '--no-fund'], { stdio: 'inherit', shell: win });
  if (r.status !== 0) {
    console.error('✗ npm install a échoué. Vérifiez votre connexion puis relancez la même commande.');
    process.exit(r.status ?? 1);
  }
}

console.log('→ Hex Studio démarre : http://127.0.0.1:3000 (Ctrl+C pour arrêter)');
const child = spawn(npm, ['run', 'dev'], { stdio: 'inherit', shell: win });
child.on('exit', (code) => process.exit(code ?? 0));

# Hex Studio

Remplaçant **personnel** de Typedream : on assemble une page d’accueil à partir de blocs, on édite le texte directement sur la page, on prévisualise ordinateur / tablette / mobile, puis on publie un site **statique** sur son propre serveur.

Pile (imposée) : Next.js 15 · TypeScript · Tailwind CSS · SQLite · Drizzle ORM · export statique.

## Première exécution (une seule commande)

Prérequis : Node 20.9 ou plus.

```bash
node scripts/first-run.mjs
```

Le script crée `.env` depuis `.env.example`, installe les dépendances si besoin, puis lance l’éditeur sur **http://127.0.0.1:3000**. Il n’écoute que sur la boucle locale.

## Utilisation

1. **Créer** un projet : il démarre avec les six sections (en-tête, preuve, fonctionnalités, tarifs, FAQ, pied de page).
2. **Cliquer sur un texte** dans l’aperçu pour le modifier (Entrée valide, Échap quitte). Réordonner, dupliquer, supprimer et ajouter des sections dans la colonne de gauche.
3. Onglet **Design** : couleur, mode clair/sombre, typographie, arrondis, espacement. Ce sont les seuls réglages : pas de CSS libre.
4. Onglet **Médias** : importer des images (PNG, JPEG, WebP, GIF, AVIF ; 10 Mo max). Trois tailles WebP sont générées automatiquement.
5. Boutons **Ordinateur / Tablette / Mobile** : largeurs réelles 1280 / 820 / 390 px. Onglet **Contrôles** : détecte les éléments qui débordent sur les trois largeurs.
6. **Publier** : construit `exports/<slug>/` (et l’envoie sur votre serveur si configuré).

## Architecture

```
src/shared/      Cœur partagé : schéma zod, jetons, rendu des sections (même code éditeur + export)
src/server/      SQLite/Drizzle, traitement d’images (sharp), publication
src/app/         Éditeur (pages) + API locale (/api/*)
src/components/  Interface d’édition
exporter/        Mini-app Next.js en `output: 'export'` : lit un projet, produit un site statique propre
tests/           Unitaires, intégration (SQLite + images), e2e (vrai `next build`)
```

Flux de publication : projet SQLite → `.build/<slug>/site.json` → `next build` dans `exporter/` (export statique) → copie dans `exports/<slug>/` → (option) `rsync`.
Le site produit n’embarque que son HTML, un peu de CSS et le JS de Next ; la FAQ fonctionne sans JavaScript.

Le design est piloté par des **jetons** (`src/shared/tokens.css`, attributs `data-palette`, `data-mode`…). La mise en page est responsive par *container queries* : l’aperçu 390 / 820 / 1280 px se comporte exactement comme le site publié.

## Emplacement des données

| Quoi | Où |
|---|---|
| Base SQLite (projets, médias) | `data/hex-studio.db` |
| Images (originales + variantes) | `data/media/<projet>/` |
| Sites générés | `exports/<slug>/` |
| Fichiers de travail | `.build/`, `exporter/out`, `exporter/public/media` (jetables) |

Les chemins se changent avec `DATA_DIR` et `EXPORTS_DIR` dans `.env`. Aucun compte, aucune facturation, aucune télémétrie (`NEXT_TELEMETRY_DISABLED=1`), aucun service hébergé.

## Sauvegarde et export

- **Export JSON portable** (bouton « Exporter JSON ») : contenu, thème et images originales en base64. « Importer un export JSON » le restaure sur n’importe quelle machine.
- **Sauvegarde complète** : copiez le dossier `data/` (arrêtez l’éditeur avant, SQLite est en mode WAL).

## Autorisations et sécurité

- **Réseau** : écoute sur `127.0.0.1` uniquement ; les requêtes d’écriture sont refusées si leur `Origin` n’est pas l’éditeur (protection contre les pages tierces). Aucune sortie réseau, sauf `rsync` si vous déployez.
- **Système de fichiers** : lecture/écriture limitées à `data/`, `exports/`, `.build/` et `exporter/`.
- **Processus** : `next build` et `rsync`, lancés sans shell, avec des arguments validés.
- **Images** : validées par leur contenu réel, noms de fichiers générés (jamais celui de l’utilisateur), SVG refusé, 50 mégapixels max.
- **Liens** : seuls `http(s)`, `mailto`, `tel`, `#ancre` et `/chemin` sont acceptés.
- **Secrets** : uniquement dans `.env` (ignoré par git). `.env.example` est fourni, sans valeur sensible.

## Déployer (une seule cible : votre serveur en SSH + rsync)

1. Dans `.env` :
   ```
   DEPLOY_HOST=exemple.org
   DEPLOY_USER=deploy
   DEPLOY_PATH=/var/www/mon-site
   DEPLOY_PORT=22
   DEPLOY_SSH_KEY=~/.ssh/id_ed25519
   ```
2. Votre clé publique doit être autorisée sur le serveur ; `rsync` doit être installé des deux côtés.
3. Servez `DEPLOY_PATH` avec le serveur web de votre choix (nginx, Caddy…).
4. Cliquez sur **Publier**, cochez « Envoyer ensuite sur ma cible ».

⚠️ `rsync --delete` rend le dossier distant identique au site : tout ce qu’il contient d’autre est supprimé. Dédiez-lui un dossier. La première connexion accepte l’empreinte du serveur (`StrictHostKeyChecking=accept-new`).

Sans configuration, Publier construit simplement `exports/<slug>/` : copiez-le où vous voulez.

## Tests

```bash
npm test            # unitaires + intégration (SQLite, images)
npm run test:e2e    # scénario complet avec un vrai next build (≈ 1 min)
npm run typecheck
```

## Hors périmètre (volontairement)

Comptes, facturation, télémétrie, analytics, plan de contrôle hébergé, plateforme de plugins, hébergement mutualisé, e-commerce avancé, adhésions, facturation d’agences.

## Notes

- Le schéma SQLite est créé de façon idempotente au premier accès (`src/server/db.ts`), les tables sont typées avec Drizzle.
- Le slug d’un projet est fixé à la création : renommer le projet ne déplace pas son dossier d’export.
- CI : `.github/workflows/build.yml` lance typecheck, tests, build et e2e ; le job `android` ne s’active que si `JARVIS-Android.zip` est présent à la racine.

// Scénario heureux de bout en bout, avec une vraie construction `next build` (export statique).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import sharp from 'sharp';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let tmp: string;

beforeAll(() => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hex-e2e-'));
  process.env.DATA_DIR = path.join(tmp, 'data');
  process.env.EXPORTS_DIR = process.env.CI_EXPORTS_DIR || path.join(tmp, 'exports'); // CI : dossier conservé pour l’artefact
  delete process.env.DEPLOY_HOST;
});
afterAll(() => fs.rmSync(tmp, { recursive: true, force: true }));

describe('créer → modifier → importer une image → publier → exporter → réimporter', () => {
  it('produit un site statique propre à partir d’un projet', async () => {
    const { createProject, saveProject, exportProject, importProject, requireProject } = await import('../../src/server/projects');
    const { addAsset } = await import('../../src/server/media');
    const { publishProject } = await import('../../src/server/publish');
    const { setIn } = await import('../../src/shared/lib');

    // 1. créer
    const p = createProject('Atelier E2E');

    // 2. importer une image locale (optimisation responsive)
    const img = await sharp({ create: { width: 1400, height: 900, channels: 3, background: '#4f46e5' } }).png().toBuffer();
    const asset = await addAsset(p.id, img, 'Hero Photo.png');

    // 3. modifier le texte (comme l’édition en ligne) + attacher l’image + changer le thème
    let doc = setIn(p.doc, ['sections', 0, 'title'], 'Bonjour depuis le test E2E');
    doc = setIn(doc, ['sections', 0, 'imageId'], asset.id);
    doc = setIn(doc, ['sections', 0, 'imageAlt'], 'Aplat indigo');
    doc = setIn(doc, ['theme', 'palette'], 'emerald');
    saveProject(p.id, { name: 'Atelier E2E', doc });

    // 4. publier (build réel) — sans déploiement
    const res = await publishProject(p.id, { deploy: false });
    expect(res.slug).toBe('atelier-e2e');
    expect(res.deploy).toBeNull();

    const index = fs.readFileSync(path.join(res.outDir, 'index.html'), 'utf8');
    expect(index).toContain('Bonjour depuis le test E2E');
    expect(index).toContain('data-palette="emerald"');
    expect(index).toMatch(/srcSet="[^"]*\/media\/[a-z0-9-]+-480\.webp 480w/);
    expect(index).toContain('alt="Aplat indigo"');
    expect(index.toLowerCase()).not.toContain('contenteditable');
    for (const v of asset.variants) expect(fs.existsSync(path.join(res.outDir, 'media', v.file))).toBe(true);
    expect(fs.existsSync(path.join(res.outDir, '_next'))).toBe(true);

    // 5. sauvegarde portable : export JSON puis import → même contenu
    const copy = await importProject(JSON.parse(JSON.stringify(exportProject(p.id))));
    expect((copy.doc.sections[0] as any).title).toBe('Bonjour depuis le test E2E');
    expect(requireProject(copy.id).assets).toHaveLength(1);

    // 6. cible non configurée : la construction réussit, l’envoi échoue proprement (erreur récupérable)
    const again = await publishProject(p.id, { deploy: true });
    expect(again.deploy?.ok).toBe(false);
    expect(again.deploy?.message).toContain('DEPLOY_HOST');
  });

  it('refuse un projet inconnu avec une erreur claire', async () => {
    const { publishProject } = await import('../../src/server/publish');
    await expect(publishProject('doesnotexist1')).rejects.toThrow('introuvable');
  });
});

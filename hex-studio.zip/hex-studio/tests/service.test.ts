import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import sharp from 'sharp';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

let tmp: string;
let P: typeof import('../src/server/projects');
let M: typeof import('../src/server/media');

const png = (w = 1200, h = 800) => sharp({ create: { width: w, height: h, channels: 3, background: '#335' } }).png().toBuffer();

beforeAll(async () => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hex-svc-'));
  process.env.DATA_DIR = tmp;
  P = await import('../src/server/projects');
  M = await import('../src/server/media');
});
afterAll(() => fs.rmSync(tmp, { recursive: true, force: true }));

describe('projets (SQLite + Drizzle)', () => {
  it('crée un projet avec le modèle de départ et un slug unique', () => {
    const a = P.createProject('Ma Page');
    const b = P.createProject('Ma Page');
    expect(a.doc.sections).toHaveLength(6);
    expect(a.slug).toBe('ma-page');
    expect(b.slug).toBe('ma-page-2');
  });

  it('refuse un nom vide, un lien javascript: et un id invalide', () => {
    expect(() => P.createProject('   ')).toThrow();
    const p = P.createProject('Validation');
    const bad = structuredClone(p.doc);
    (bad.sections[0] as any).ctaHref = 'javascript:alert(1)';
    expect(() => P.saveProject(p.id, { doc: bad })).toThrow();
    expect(() => P.getProject('../../etc')).toThrow();
  });

  it('refuse une image inconnue du projet', () => {
    const p = P.createProject('Image fantôme');
    const d = structuredClone(p.doc);
    (d.sections[0] as any).imageId = 'unknownmedia1';
    expect(() => P.saveProject(p.id, { doc: d })).toThrow();
  });
});

describe('médias', () => {
  it('rejette un fichier qui n’est pas une image, même nommé .png', async () => {
    const p = P.createProject('Média invalide');
    await expect(M.addAsset(p.id, Buffer.from('<svg onload=alert(1)/>'), 'x.png')).rejects.toThrow();
  });

  it('génère des variantes WebP, utilise un nom sûr et bloque la suppression d’un média utilisé', async () => {
    const p = P.createProject('Média ok');
    const a = await M.addAsset(p.id, await png(), '../../Ma Photo (1).PNG');
    expect(a.variants.length).toBeGreaterThanOrEqual(2);
    expect(a.variants.every((v) => /^[a-z0-9.-]+\.webp$/.test(v.file))).toBe(true);
    expect(fs.existsSync(path.join(M.mediaDir(p.id), a.variants[0].file))).toBe(true);

    const d = structuredClone(p.doc);
    (d.sections[0] as any).imageId = a.id;
    P.saveProject(p.id, { doc: d });
    expect(() => M.deleteAsset(p.id, a.id)).toThrow();

    (d.sections[0] as any).imageId = null;
    P.saveProject(p.id, { doc: d });
    M.deleteAsset(p.id, a.id);
    expect(P.requireProject(p.id).assets).toHaveLength(0);
  });

  it('refuse les noms de fichiers dangereux à la lecture', () => {
    const p = P.createProject('Lecture');
    expect(() => M.readMediaFile(p.id, '../hex-studio.db')).toThrow();
  });
});

describe('export / import JSON portable', () => {
  it('conserve contenu, thème et image après un aller-retour', async () => {
    const p = P.createProject('Aller retour');
    const a = await M.addAsset(p.id, await png(900, 600), 'cover.png');
    const d = structuredClone(p.doc);
    (d.sections[0] as any).imageId = a.id;
    d.theme.palette = 'rose';
    P.saveProject(p.id, { doc: d });

    const file = JSON.parse(JSON.stringify(P.exportProject(p.id)));
    const copy = await P.importProject(file);
    expect(copy.id).not.toBe(p.id);
    expect(copy.doc.theme.palette).toBe('rose');
    expect(copy.assets).toHaveLength(1);
    expect((copy.doc.sections[0] as any).imageId).toBe(copy.assets[0].id);
  });

  it('rejette un fichier d’export invalide sans rien créer', async () => {
    const before = P.listProjects().length;
    await expect(P.importProject({ format: 'autre' })).rejects.toThrow();
    expect(P.listProjects().length).toBe(before);
  });
});

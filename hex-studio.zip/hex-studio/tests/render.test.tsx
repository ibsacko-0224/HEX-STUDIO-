import { describe, expect, it } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { Site } from '../src/shared/render/Site';
import { starterDoc } from '../src/shared/defaults';
import { setIn } from '../src/shared/lib';

const ASSET = { id: 'abc123def456', variants: [{ w: 960, h: 640, file: 'photo-960.webp' }, { w: 480, h: 320, file: 'photo-480.webp' }] };

describe('transformation document → HTML statique', () => {
  const doc = starterDoc();
  const html = renderToStaticMarkup(<Site doc={doc} assets={[]} mediaBase="/media" />);

  it('rend les six sections et les ancres', () => {
    expect(doc.sections).toHaveLength(6);
    for (const t of ['header', 'proof', 'features', 'pricing', 'faq', 'footer']) expect(html).toContain(`data-type="${t}"`);
    expect(html).toContain('id="pricing"');
    expect(html).toContain('Votre projet, en ligne dès ce soir');
  });

  it('ne contient aucune trace d’édition', () => {
    expect(html.toLowerCase()).not.toContain('contenteditable');
    expect(html).not.toContain('data-editing');
  });

  it('rend la FAQ sans JavaScript (details/summary) et trois formules de prix', () => {
    expect(html.match(/<details/g)).toHaveLength(3);
    expect(html).toContain('Découverte');
    expect(html).toContain('Équipe');
  });

  it('applique les jetons de design via des attributs, pas du CSS libre', () => {
    const d = setIn(doc, ['theme'], { palette: 'emerald', font: 'editorial', radius: 'xl', spacing: 'airy', mode: 'dark' });
    const h = renderToStaticMarkup(<Site doc={d} assets={[]} mediaBase="/media" />);
    expect(h).toContain('data-palette="emerald"');
    expect(h).toContain('data-mode="dark"');
    expect(h).not.toContain('style=');
  });

  it('échappe le HTML saisi par l’utilisateur', () => {
    const d = setIn(doc, ['sections', 0, 'title'], '<script>alert(1)</script>');
    const h = renderToStaticMarkup(<Site doc={d} assets={[]} mediaBase="/media" />);
    expect(h).not.toContain('<script>alert');
    expect(h).toContain('&lt;script&gt;');
  });

  it('génère un srcset responsive trié avec dimensions explicites', () => {
    const d = setIn(setIn(doc, ['sections', 0, 'imageId'], ASSET.id), ['sections', 0, 'imageAlt'], 'Capture');
    const h = renderToStaticMarkup(<Site doc={d} assets={[ASSET]} mediaBase="/media" />);
    expect(h).toMatch(/srcSet="\/media\/photo-480\.webp 480w, \/media\/photo-960\.webp 960w"/);
    expect(h).toContain('width="960"');
    expect(h).toContain('alt="Capture"');
  });

  it('affiche un état clair si l’image est introuvable', () => {
    const d = setIn(doc, ['sections', 0, 'imageId'], 'zzzzzzzzzzzz');
    expect(renderToStaticMarkup(<Site doc={d} assets={[]} mediaBase="/media" />)).toContain('Image introuvable');
  });
});

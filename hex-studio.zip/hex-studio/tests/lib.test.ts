import { describe, expect, it } from 'vitest';
import { isSafeHref, moveItem, safeFilename, setIn, slugify } from '../src/shared/lib';

describe('setIn', () => {
  it('met à jour un chemin profond sans muter l’original', () => {
    const src = { items: [{ title: 'a' }, { title: 'b' }] };
    const next = setIn(src, ['items', 1, 'title'], 'z');
    expect(next.items[1].title).toBe('z');
    expect(src.items[1].title).toBe('b');
    expect(next.items[0]).toBe(src.items[0]);
  });
});

describe('slugify / safeFilename', () => {
  it('retire accents et caractères spéciaux', () => {
    expect(slugify('Ma Page d’Été !')).toBe('ma-page-d-ete');
    expect(slugify('***')).toBe('site');
  });
  it('neutralise les chemins et extensions douteuses', () => {
    expect(safeFilename('../../etc/passwd.png')).toEqual({ base: 'passwd', ext: 'png' });
    expect(safeFilename('Été à la mer.JPG')).toEqual({ base: 'ete-a-la-mer', ext: 'jpg' });
    expect(safeFilename('C:\\Users\\x\\photo.final.webp').base).toBe('photo-final');
  });
});

describe('isSafeHref', () => {
  it('accepte les liens attendus', () => {
    for (const ok of ['', '#pricing', '/mentions', 'https://example.com/a?b=1', 'mailto:a@b.fr', 'tel:+33 1 23 45 67 89']) {
      expect(isSafeHref(ok)).toBe(true);
    }
  });
  it('refuse javascript:, data: et les URLs protocole-relatif', () => {
    for (const bad of ['javascript:alert(1)', 'JaVaScRiPt:alert(1)', 'data:text/html,x', '//evil.com', 'ftp://x.y', 'https://a b.com']) {
      expect(isSafeHref(bad)).toBe(false);
    }
  });
});

describe('moveItem', () => {
  it('déplace et ignore les bornes invalides', () => {
    expect(moveItem([1, 2, 3], 0, 2)).toEqual([2, 3, 1]);
    expect(moveItem([1, 2, 3], 0, 5)).toEqual([1, 2, 3]);
  });
});
